import rawSeed from '../data/seed.json';
import type { CategoryDef, MaintenanceData, ModelRevision } from '../types';

export const STORAGE_KEY = 'rodaleve_manutencao_v1';

export function getSeedData(): MaintenanceData {
  return JSON.parse(JSON.stringify(rawSeed)) as MaintenanceData;
}

export function normalizeDataModelNames(data: MaintenanceData): MaintenanceData {
  if (!data || !data.revs) return data;
  const revs: MaintenanceData['revs'] = {};
  for (const revKey of Object.keys(data.revs)) {
    revs[revKey] = (data.revs[revKey] || []).map((model) => ({
      ...model,
      m: model.m.trim().toLocaleUpperCase('pt-BR'),
    }));
  }
  return { ...data, revs };
}

export function getCustomModelPhoto(
  photos: Record<string, string> | undefined,
  modelName: string
): string | undefined {
  if (!photos) return undefined;
  const trimmed = modelName.trim();
  if (photos[modelName]) return photos[modelName];
  if (photos[trimmed]) return photos[trimmed];
  const lower = trimmed.toLowerCase();
  const matchedKey = Object.keys(photos).find((k) => k.trim().toLowerCase() === lower);
  return matchedKey ? photos[matchedKey] : undefined;
}

export function loadInitialData(): MaintenanceData {
  const seed = normalizeDataModelNames(getSeedData());
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as MaintenanceData;
      if (parsed && typeof parsed === 'object' && (parsed.ts || 0) > (seed.ts || 0)) {
        return normalizeDataModelNames(parsed);
      }
    }
  } catch {
    // Fallback to seed if storage is corrupted
  }
  return seed;
}

export function persistData(data: MaintenanceData): { ok: boolean; data: MaintenanceData; error?: string } {
  const updated: MaintenanceData = { ...data, ts: Date.now() };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return { ok: true, data: updated };
  } catch {
    return {
      ok: false,
      data: updated,
      error: 'Sem espaço no navegador para salvar. Use fotos menores ou baixe o backup.',
    };
  }
}

export function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function computeModelTotal(model: ModelRevision, parts: MaintenanceData['parts']): number {
  return model.i.reduce((sum, item) => {
    const part = parts[item.p];
    if (!part) return sum;
    return sum + part.p * item.q;
  }, 0);
}

export const DEFAULT_CATEGORIES: CategoryDef[] = [
  { id: 'cub_scooter', label: 'Cub & Scooter' },
  { id: 'street_trail', label: 'Street & Trail' },
  { id: 'alta', label: 'Alta Cilindrada' },
];

export const CATEGORY_LABELS: Record<string, string> = {
  all: 'Todos os modelos',
  cub_scooter: 'Cub & Scooter',
  street_trail: 'Street & Trail',
  alta: 'Alta Cilindrada',
};

export function getModelCategory(modelName: string): string {
  const lower = modelName.toLowerCase().trim();
  if (
    lower.includes('pop') ||
    lower.includes('biz') ||
    lower.includes('elite') ||
    lower.includes('pcx') ||
    lower.includes('adv')
  ) {
    return 'cub_scooter';
  }
  if (
    lower.includes('500') ||
    lower.includes('650') ||
    lower.includes('750') ||
    lower.includes('1000') ||
    lower.includes('1100') ||
    lower.includes('transalp') ||
    lower.includes('africa') ||
    lower.includes('hornet') ||
    lower.includes('nx ') ||
    lower.includes('nc ')
  ) {
    return 'alta';
  }
  return 'street_trail';
}

export function getAllCategories(data: MaintenanceData): CategoryDef[] {
  const stored = data.categories || [];
  const storedById = new Map(stored.filter((c) => c.id && c.label).map((c) => [c.id, c]));
  const defaults = DEFAULT_CATEGORIES.map((def) => storedById.get(def.id) || def);
  const defaultIds = new Set(DEFAULT_CATEGORIES.map((c) => c.id));
  const custom = stored.filter((c) => c.id && c.label && !defaultIds.has(c.id));
  return [...defaults, ...custom];
}

export function slugifyCategoryId(label: string): string {
  return (
    label
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '') || `cat_${Date.now()}`
  );
}

export function resolveModelCategory(
  model: ModelRevision,
  categories: CategoryDef[]
): CategoryDef {
  if (model.cat) {
    const found = categories.find((c) => c.id === model.cat);
    if (found) return found;
  }
  const fallbackId = getModelCategory(model.m);
  return (
    categories.find((c) => c.id === fallbackId) || {
      id: fallbackId,
      label: CATEGORY_LABELS[fallbackId] || 'Street & Trail',
    }
  );
}

export function resizeImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Falha ao ler arquivo de imagem.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Imagem inválida.'));
      img.onload = () => {
        const scale = Math.min(1, 600 / img.width);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas não disponível.'));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export function downloadFile(filename: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function exportStandaloneHtml(data: MaintenanceData): Promise<boolean> {
  try {
    const res = await fetch('/standalone-template.html');
    if (!res.ok) return false;
    const template = await res.text();
    const escapedSeed = JSON.stringify(data).replace(/</g, '\\u003c');
    const finalHtml = template.replace('__SEED_JSON__', escapedSeed);
    downloadFile('rodaleve-manutencao.html', finalHtml, 'text/html;charset=utf-8');
    return true;
  } catch {
    return false;
  }
}

export const WHATSAPP_DISPLAY = '(77) 2888-0003';

export function buildWhatsAppUrl(message?: string): string {
  const defaultMsg = 'Olá! Gostaria de agendar a revisão da minha moto.';
  const text = encodeURIComponent(message || defaultMsg);
  return `https://wa.me/557728880003?text=${text}`;
}
