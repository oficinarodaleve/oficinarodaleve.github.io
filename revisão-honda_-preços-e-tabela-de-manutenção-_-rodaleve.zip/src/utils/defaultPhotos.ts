const DEFAULT_MODEL_PHOTOS: Record<string, string> = {
  'pop 110i': '/src/assets/images/honda_pop_110i_1794959622758.jpg',
  'biz 125': '/src/assets/images/honda_biz_125_1794959622064.jpg',
  'elite 125': '/src/assets/images/honda_elite_125_1794959622606.jpg',
  'pcx 160': '/src/assets/images/honda_pcx_160_1794959622448.jpg',
  'adv 160': '/src/assets/images/honda_adv_160_1794959622959.jpg',
  'cg 160': '/src/assets/images/honda_cg_160_1794959624143.jpg',
  'bros 160': '/src/assets/images/honda_bros_160_1794959624097.jpg',
  'xre 190': '/src/assets/images/honda_xre_190_1794959624922.jpg',
  'cb 300f twister': '/src/assets/images/honda_cb300f_twister_1794959625038.jpg',
  'sahara 300': '/src/assets/images/honda_sahara_300_1794959626100.jpg',
  'tornado 300': '/src/assets/images/honda_tornado_300_1794959626377.jpg',
  'cb 500x': '/src/assets/images/honda_cb_500x_1794959627105.jpg',
  'cb 650r': '/src/assets/images/honda_cb_650r_1794959627238.jpg',
  'cb hornet 500': '/src/assets/images/honda_hornet_500_1794959627631.jpg',
  'nx 500': '/src/assets/images/honda_nx_500_1794959628442.jpg',
  'cb hornet 750': '/src/assets/images/honda_hornet_750_1794959629436.jpg',
  'cb hornet 1000': '/src/assets/images/honda_hornet_1000_1794959629838.jpg',
  'nc 750x': '/src/assets/images/honda_nc_750x_1794959630019.jpg',
  'nc 750x dct': '/src/assets/images/honda_nc_750x_1794959630019.jpg',
  'xl 750 transalp': '/src/assets/images/honda_xl750_transalp_1794959630396.jpg',
  'crf 1100 africa twin': '/src/assets/images/honda_africa_twin_1794959710787.jpg',
  'crf 1100 africa twin dct': '/src/assets/images/honda_africa_twin_1794959710787.jpg',
};

export function getDefaultModelPhoto(modelName: string): string | undefined {
  const key = modelName.trim().replace(/\s+/g, ' ').toLowerCase();
  if (DEFAULT_MODEL_PHOTOS[key]) {
    return DEFAULT_MODEL_PHOTOS[key];
  }
  const matchedKey = Object.keys(DEFAULT_MODEL_PHOTOS).find(
    (k) => key.includes(k) || k.includes(key)
  );
  return matchedKey ? DEFAULT_MODEL_PHOTOS[matchedKey] : undefined;
}
