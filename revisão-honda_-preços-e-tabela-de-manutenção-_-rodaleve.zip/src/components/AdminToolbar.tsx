import React, { useRef, useState } from 'react';
import { Check, Download, FileJson, Pencil, RotateCcw, Upload, X } from 'lucide-react';

interface AdminToolbarProps {
  isEditing: boolean;
  onToggleEditing: () => void;
  onDownloadHtml: () => Promise<void>;
  onExportJson: () => void;
  onImportJson: (file: File) => void;
  onResetDefault: () => void;
  onExitAdmin: () => void;
  statusMessage: { type: 'ok' | 'err'; text: string } | null;
  onClearStatus: () => void;
}

export const AdminToolbar: React.FC<AdminToolbarProps> = ({
  isEditing,
  onToggleEditing,
  onDownloadHtml,
  onExportJson,
  onImportJson,
  onResetDefault,
  onExitAdmin,
  statusMessage,
  onClearStatus,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [downloadingHtml, setDownloadingHtml] = useState(false);

  const handleHtmlClick = async () => {
    setDownloadingHtml(true);
    await onDownloadHtml();
    setDownloadingHtml(false);
  };

  return (
    <div className="bg-zinc-100 dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onToggleEditing}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              isEditing
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                : 'bg-[#E31E24] hover:bg-[#B91419] text-white'
            }`}
          >
            {isEditing ? <Check className="w-3.5 h-3.5" /> : <Pencil className="w-3.5 h-3.5" />}
            {isEditing ? 'Concluir edição' : 'Editar tabela'}
          </button>

          <button
            type="button"
            onClick={handleHtmlClick}
            disabled={downloadingHtml}
            title="Gera o site em arquivo único HTML com todas as alterações gravadas, pronto para publicar"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-white dark:bg-zinc-800 text-zinc-800 dark:text-zinc-100 border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            {downloadingHtml ? 'Gerando HTML…' : 'Baixar HTML atualizado'}
          </button>

          <button
            type="button"
            onClick={onExportJson}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-white dark:bg-zinc-800 text-zinc-800 dark:text-zinc-100 border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileJson className="w-3.5 h-3.5" />
            Exportar backup
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-white dark:bg-zinc-800 text-zinc-800 dark:text-zinc-100 border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" />
            Importar backup
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                onImportJson(file);
                e.target.value = '';
              }
            }}
          />

          {!confirmReset ? (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-white dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border border-zinc-300 dark:border-zinc-700 hover:text-[#E31E24] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Restaurar padrão
            </button>
          ) : (
            <div className="inline-flex items-center gap-1.5 bg-white dark:bg-zinc-800 border border-red-300 dark:border-red-800 rounded-lg px-2.5 py-1">
              <span className="text-xs text-zinc-700 dark:text-zinc-200 font-medium">Descartar edições?</span>
              <button
                type="button"
                onClick={() => {
                  onResetDefault();
                  setConfirmReset(false);
                }}
                className="px-2 py-1 text-xs font-semibold bg-[#E31E24] text-white rounded cursor-pointer"
              >
                Confirmar
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="px-2 py-1 text-xs text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3 text-xs text-zinc-500 dark:text-zinc-400">
          <span>Alterações salvas localmente neste navegador.</span>
          <button
            type="button"
            onClick={onExitAdmin}
            className="text-zinc-700 dark:text-zinc-300 hover:text-[#E31E24] font-medium underline underline-offset-2 whitespace-nowrap cursor-pointer"
          >
            Sair do gestor
          </button>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`border-t text-xs px-4 sm:px-6 py-2 flex items-center justify-between max-w-[1200px] mx-auto ${
            statusMessage.type === 'err'
              ? 'border-red-200 dark:border-red-900 text-red-700 dark:text-red-300'
              : 'border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300'
          }`}
        >
          <span>{statusMessage.text}</span>
          <button
            type="button"
            onClick={onClearStatus}
            aria-label="Fechar aviso"
            className="p-1 hover:opacity-75 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
