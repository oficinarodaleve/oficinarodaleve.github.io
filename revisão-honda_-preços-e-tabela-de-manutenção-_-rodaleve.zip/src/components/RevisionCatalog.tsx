import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  Copy,
  GripVertical,
  LayoutGrid,
  List,
  Lock,
  Pencil,
  Plus,
  Search,
  Unlock,
  X,
} from 'lucide-react';
import type { ActiveTab, MaintenanceData, ModelCategory } from '../types';
import {
  buildWhatsAppUrl,
  computeModelTotal,
  DEFAULT_CATEGORIES,
  formatBRL,
  getAllCategories,
  getCustomModelPhoto,
  resolveModelCategory,
} from '../utils/maintenance';
import { ModelCard } from './ModelCard';
import { PartNameText } from './PartNameText';
import { getDefaultModelPhoto } from '../utils/defaultPhotos';

interface RevisionCatalogProps {
  data: MaintenanceData;
  activeTab: ActiveTab;
  isAdmin: boolean;
  isEditing: boolean;
  onSelectTab: (tab: ActiveTab) => void;
  onUpdateModelName: (revKey: string, modelIndex: number, newName: string) => void;
  onUpdateModelCategory: (revKey: string, modelIndex: number, categoryId: string) => void;
  onUploadPhoto: (modelName: string, file: File) => void;
  onRemovePhoto: (modelName: string) => void;
  onUpdateItemQty: (revKey: string, modelIndex: number, itemIndex: number, qty: number) => void;
  onUpdatePartPrice: (partId: string, price: number) => void;
  onRemoveItem: (revKey: string, modelIndex: number, itemIndex: number) => void;
  onAddItem: (revKey: string, modelIndex: number, partId: string) => void;
  onDeleteModel: (revKey: string, modelIndex: number) => void;
  onToggleHiddenModel: (revKey: string, modelIndex: number) => void;
  onAddModel: (
    revKey: string,
    modelName?: string,
    addToAllRevisions?: boolean,
    categoryId?: string
  ) => void;
  onAddCategory: (label: string) => string | null;
  onRenameCategory: (categoryId: string, newLabel: string) => void;
  onDeleteCategory: (categoryId: string) => void;
  onToggleHiddenCategory: (categoryId: string) => void;
  onReorderModels: (revKey: string, fromIndex: number, toIndex: number) => void;
  onToggleHiddenRevision: (revKey: string) => void;
  onCopyRevisionToOthers: (sourceRevKey: string) => void;
}

const REVISION_TABS: Array<{ key: ActiveTab; label: string }> = [
  { key: '1', label: '1ª Revisão' },
  { key: '2', label: '2ª Revisão' },
  { key: '3', label: '3ª Revisão' },
  { key: '4', label: '4ª Revisão' },
  { key: '5', label: '5ª Revisão' },
  { key: '6', label: '6ª Revisão' },
  { key: '7', label: '7ª Revisão' },
];

export const RevisionCatalog: React.FC<RevisionCatalogProps> = ({
  data,
  activeTab,
  isAdmin,
  isEditing,
  onSelectTab,
  onUpdateModelName,
  onUpdateModelCategory,
  onUploadPhoto,
  onRemovePhoto,
  onUpdateItemQty,
  onUpdatePartPrice,
  onRemoveItem,
  onAddItem,
  onDeleteModel,
  onToggleHiddenModel,
  onAddModel,
  onAddCategory,
  onRenameCategory,
  onDeleteCategory,
  onToggleHiddenCategory,
  onReorderModels,
  onToggleHiddenRevision,
  onCopyRevisionToOthers,
}) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<ModelCategory>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newModelName, setNewModelName] = useState('');
  const [selectedCatChoice, setSelectedCatChoice] = useState<string>('street_trail');
  const [inlineNewCatLabel, setInlineNewCatLabel] = useState('');
  const [addToAllRevs, setAddToAllRevs] = useState(true);
  const [addError, setAddError] = useState<string | null>(null);

  const [showNewCatForm, setShowNewCatForm] = useState(false);
  const [standaloneCatLabel, setStandaloneCatLabel] = useState('');
  const [renamingCatId, setRenamingCatId] = useState<string | null>(null);
  const [draftCatLabel, setDraftCatLabel] = useState('');
  const [confirmCopyRev, setConfirmCopyRev] = useState(false);
  const [draggedModelIndex, setDraggedModelIndex] = useState<number | null>(null);
  const [dropTargetIndex, setDropTargetIndex] = useState<number | null>(null);

  const canManageModels = isAdmin || isEditing;
  const allCategories = useMemo(() => getAllCategories(data), [data]);
  const defaultCategoryIds = useMemo(
    () => new Set(DEFAULT_CATEGORIES.map((c) => c.id)),
    []
  );
  const hiddenCategories = useMemo(
    () => new Set(data.hiddenCategories || []),
    [data.hiddenCategories]
  );
  const visibleCategories = useMemo(
    () =>
      canManageModels
        ? allCategories
        : allCategories.filter((c) => !hiddenCategories.has(c.id)),
    [canManageModels, allCategories, hiddenCategories]
  );

  const hiddenRevs = useMemo(() => new Set(data.hiddenRevs || []), [data.hiddenRevs]);
  const visibleTabs = useMemo(
    () => (canManageModels ? REVISION_TABS : REVISION_TABS.filter((t) => !hiddenRevs.has(t.key))),
    [canManageModels, hiddenRevs]
  );

  const revisionKey = ['1', '2', '3', '4', '5', '6', '7'].includes(activeTab) ? activeTab : '1';
  const models = data.revs[revisionKey] || [];

  useEffect(() => {
    setDraggedModelIndex(null);
    setDropTargetIndex(null);
    setConfirmCopyRev(false);
  }, [revisionKey]);

  useEffect(() => {
    if (!canManageModels && category !== 'all' && hiddenCategories.has(category)) {
      setCategory('all');
    }
  }, [canManageModels, category, hiddenCategories]);

  const filteredModels = useMemo(() => {
    const q = query.trim().toLowerCase();
    return models
      .map((model, originalIndex) => ({
        model,
        originalIndex,
        resolvedCat: resolveModelCategory(model, allCategories),
      }))
      .filter(({ model, resolvedCat }) => {
        if (!canManageModels && (model.hidden || hiddenCategories.has(resolvedCat.id))) {
          return false;
        }
        if (category !== 'all' && resolvedCat.id !== category) {
          return false;
        }
        if (!q) return true;
        if (model.m.toLowerCase().includes(q)) return true;
        return model.i.some((item) => {
          const part = data.parts[item.p];
          if (!part) return false;
          return part.n.toLowerCase().includes(q) || part.c.toLowerCase().includes(q);
        });
      });
  }, [models, query, category, data.parts, allCategories, canManageModels, hiddenCategories]);

  return (
    <section aria-label="Tabela de revisões por modelo">
      {/* Segmented Revision Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-zinc-200 dark:border-zinc-800">
        <div
          role="tablist"
          aria-label="Selecione o número da revisão"
          className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full"
        >
          {visibleTabs.map((tab) => {
            const active = revisionKey === tab.key;
            const isHidden = hiddenRevs.has(tab.key);

            if (!canManageModels) {
              return (
                <button
                  key={tab.key}
                  role="tab"
                  type="button"
                  aria-selected={active}
                  onClick={() => onSelectTab(tab.key)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#E31E24] text-white'
                      : 'bg-white dark:bg-[#16161A] text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700'
                  }`}
                >
                  {tab.label}
                </button>
              );
            }

            return (
              <div
                key={tab.key}
                className={`inline-flex items-center rounded-lg border shrink-0 transition-colors ${
                  active && !isHidden
                    ? 'bg-[#E31E24] border-[#E31E24] text-white'
                    : active && isHidden
                      ? 'bg-zinc-800 dark:bg-zinc-200 border-dashed border-amber-400 text-white dark:text-zinc-900'
                      : isHidden
                        ? 'bg-zinc-100 dark:bg-zinc-900/60 border-dashed border-zinc-300 dark:border-zinc-700 text-zinc-400 dark:text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-200'
                        : 'bg-white dark:bg-[#16161A] border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-300 dark:hover:border-zinc-700'
                }`}
              >
                <button
                  role="tab"
                  type="button"
                  aria-selected={active}
                  onClick={() => onSelectTab(tab.key)}
                  className={`pl-3.5 pr-2 py-2 text-sm font-semibold whitespace-nowrap cursor-pointer ${
                    isHidden ? 'line-through decoration-1' : ''
                  }`}
                >
                  {tab.label}
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleHiddenRevision(tab.key);
                  }}
                  aria-pressed={isHidden}
                  aria-label={
                    isHidden
                      ? `Destrancar e exibir ${tab.label}`
                      : `Trancar e ocultar ${tab.label}`
                  }
                  title={
                    isHidden
                      ? `${tab.label} oculta dos clientes — clique no cadeado para exibir`
                      : `Clique no cadeado para ocultar ${tab.label} dos clientes`
                  }
                  className={`pr-2.5 pl-1.5 py-2 border-l transition-colors cursor-pointer ${
                    active && !isHidden
                      ? 'border-white/25 text-white/85 hover:text-white'
                      : isHidden
                        ? 'border-amber-400/40 text-amber-500 hover:text-amber-400'
                        : 'border-zinc-200 dark:border-zinc-800 text-zinc-400 hover:text-[#E31E24]'
                  }`}
                >
                  {isHidden ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                </button>
              </div>
            );
          })}
        </div>

        {canManageModels && (
          <div className="flex flex-wrap items-center gap-2">
            {!confirmCopyRev ? (
              <button
                type="button"
                onClick={() => setConfirmCopyRev(true)}
                title={`Copiar modelos, ordem, categorias, visibilidade e peças da ${revisionKey}ª Revisão para todas as outras`}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#16161A] text-zinc-800 dark:text-zinc-100 hover:border-[#E31E24] hover:text-[#E31E24] whitespace-nowrap shrink-0 transition-colors cursor-pointer"
              >
                <Copy className="w-4 h-4" />
                Copiar {revisionKey}ª p/ demais
              </button>
            ) : (
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-300 dark:border-red-800 bg-white dark:bg-[#16161A] text-xs">
                <span className="font-medium text-zinc-700 dark:text-zinc-200 whitespace-nowrap">
                  Copiar {revisionKey}ª p/ todas?
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onCopyRevisionToOthers(revisionKey);
                    setConfirmCopyRev(false);
                  }}
                  className="px-2.5 py-1 rounded bg-[#E31E24] hover:bg-[#B91419] text-white font-semibold cursor-pointer"
                >
                  Confirmar
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmCopyRev(false)}
                  className="px-2 py-1 text-zinc-500 hover:text-zinc-900 dark:hover:text-white cursor-pointer"
                >
                  Cancelar
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                setShowNewCatForm((prev) => !prev);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-[#16161A] text-zinc-800 dark:text-zinc-100 hover:border-[#E31E24] hover:text-[#E31E24] whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Nova categoria
            </button>
            <button
              type="button"
              onClick={() => {
                setShowAddForm((prev) => {
                  const next = !prev;
                  if (next && category !== 'all') {
                    setSelectedCatChoice(category);
                  }
                  return next;
                });
                setAddError(null);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold bg-[#E31E24] hover:bg-[#B91419] text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Adicionar modelo
            </button>
          </div>
        )}
      </div>

      {canManageModels && hiddenRevs.has(revisionKey) && (
        <div className="mt-4 px-4 py-2.5 rounded-lg border border-dashed border-amber-400/80 dark:border-amber-600/70 bg-amber-50/70 dark:bg-amber-950/20 flex flex-wrap items-center justify-between gap-2 text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2 font-medium">
            <Lock className="w-3.5 h-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
            <span>
              A <strong>{revisionKey}ª Revisão</strong> está trancada e oculta para os clientes no modo de visualização.
            </span>
          </div>
          <button
            type="button"
            onClick={() => onToggleHiddenRevision(revisionKey)}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white transition-colors cursor-pointer"
          >
            <Unlock className="w-3 h-3" />
            Exibir para clientes
          </button>
        </div>
      )}

      {canManageModels && showNewCatForm && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const createdId = onAddCategory(standaloneCatLabel);
            if (createdId) {
              setStandaloneCatLabel('');
              setShowNewCatForm(false);
              setCategory(createdId);
              setSelectedCatChoice(createdId);
              setShowAddForm(true);
            }
          }}
          className="mt-4 bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 space-y-2.5 shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
              Acrescentar nova categoria
            </h3>
            <button
              type="button"
              onClick={() => setShowNewCatForm(false)}
              aria-label="Fechar criação de categoria"
              className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex flex-col sm:flex-row gap-2.5">
            <input
              type="text"
              autoFocus
              value={standaloneCatLabel}
              onChange={(e) => setStandaloneCatLabel(e.target.value)}
              placeholder="Ex: Quadriciclos, Off-Road, Elétricas…"
              aria-label="Nome da nova categoria"
              className="flex-1 px-3 py-2 text-sm rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold bg-[#E31E24] hover:bg-[#B91419] text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Criar categoria
            </button>
          </div>
        </form>
      )}

      {canManageModels && showAddForm && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const clean = newModelName.trim();
            if (!clean) {
              setAddError('Informe o nome do novo modelo.');
              return;
            }
            let finalCatId = selectedCatChoice;
            if (selectedCatChoice === '__new__') {
              const createdId = onAddCategory(inlineNewCatLabel);
              if (!createdId) {
                setAddError('Informe o nome da nova categoria.');
                return;
              }
              finalCatId = createdId;
            }
            onAddModel(revisionKey, clean, addToAllRevs, finalCatId);
            setNewModelName('');
            setInlineNewCatLabel('');
            setSelectedCatChoice(finalCatId);
            setCategory(finalCatId);
            setAddError(null);
            setShowAddForm(false);
          }}
          className="mt-4 bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 sm:p-5 space-y-3 shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
              Incluir novo modelo de motocicleta
            </h3>
            <button
              type="button"
              onClick={() => {
                setShowAddForm(false);
                setAddError(null);
              }}
              aria-label="Fechar formulário"
              className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label
                htmlFor="new-model-name"
                className="block text-xs font-semibold text-zinc-600 dark:text-zinc-300"
              >
                Nome do modelo
              </label>
              <input
                id="new-model-name"
                type="text"
                autoFocus
                value={newModelName}
                onChange={(e) => {
                  setNewModelName(e.target.value.toLocaleUpperCase('pt-BR'));
                  if (addError) setAddError(null);
                }}
                placeholder="Ex: FORZA 350, TRX 420 FOURTRAX, CRF 300F…"
                className="w-full px-3 py-2 text-sm uppercase rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
              />
            </div>

            <div className="space-y-1">
              <label
                htmlFor="new-model-category"
                className="block text-xs font-semibold text-zinc-600 dark:text-zinc-300"
              >
                Categoria
              </label>
              <select
                id="new-model-category"
                value={selectedCatChoice}
                onChange={(e) => {
                  setSelectedCatChoice(e.target.value);
                  if (addError) setAddError(null);
                }}
                className="w-full px-3 py-2 text-sm rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
              >
                {allCategories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
                <option value="__new__">+ Criar nova categoria…</option>
              </select>
            </div>
          </div>

          {selectedCatChoice === '__new__' && (
            <div className="space-y-1">
              <label
                htmlFor="inline-new-category"
                className="block text-xs font-semibold text-zinc-600 dark:text-zinc-300"
              >
                Nome da nova categoria
              </label>
              <input
                id="inline-new-category"
                type="text"
                value={inlineNewCatLabel}
                onChange={(e) => {
                  setInlineNewCatLabel(e.target.value);
                  if (addError) setAddError(null);
                }}
                placeholder="Ex: Quadriciclos, Off-Road, Competição…"
                className="w-full px-3 py-2 text-sm rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
              />
            </div>
          )}

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
            <label className="inline-flex items-center gap-2 text-xs text-zinc-600 dark:text-zinc-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={addToAllRevs}
                onChange={(e) => setAddToAllRevs(e.target.checked)}
                className="rounded border-zinc-300 text-[#E31E24] focus:ring-[#E31E24]"
              />
              <span>Incluir em todas as revisões (1ª à 7ª). Desmarque para incluir apenas na {revisionKey}ª revisão.</span>
            </label>

            <button
              type="submit"
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold bg-[#E31E24] hover:bg-[#B91419] text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Salvar modelo
            </button>
          </div>

          {addError && <p className="text-xs font-medium text-[#E31E24]">{addError}</p>}
        </form>
      )}

      {/* Search, Category Filter & View Toggle */}
      <div className="py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar modelo, peça ou código…"
            aria-label="Buscar modelo, peça ou código"
            className="w-full pl-10 pr-9 py-2.5 text-sm rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#16161A] text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 focus:outline-none focus:border-[#E31E24]"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="Limpar busca"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between sm:justify-end gap-3">
          <div className="flex items-center gap-1 p-1 bg-zinc-100 dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 overflow-x-auto max-w-full">
            <button
              type="button"
              onClick={() => setCategory('all')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                category === 'all'
                  ? 'bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              Todos os modelos
            </button>
            {visibleCategories.map((cat) => {
              const active = category === cat.id;
              const isCustom = !defaultCategoryIds.has(cat.id);
              const isCatHidden = hiddenCategories.has(cat.id);
              const isRenamingThisCat = canManageModels && renamingCatId === cat.id;

              if (isRenamingThisCat) {
                return (
                  <form
                    key={cat.id}
                    onSubmit={(e) => {
                      e.preventDefault();
                      const clean = draftCatLabel.trim();
                      if (clean) {
                        onRenameCategory(cat.id, clean);
                      }
                      setRenamingCatId(null);
                    }}
                    className="inline-flex items-center gap-1 shrink-0 px-1"
                  >
                    <input
                      type="text"
                      autoFocus
                      value={draftCatLabel}
                      onChange={(e) => setDraftCatLabel(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Escape') {
                          setRenamingCatId(null);
                        }
                      }}
                      aria-label={`Novo nome para ${cat.label}`}
                      className="w-32 px-2 py-1 text-xs font-medium rounded-md border border-[#E31E24] bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white focus:outline-none"
                    />
                    <button
                      type="submit"
                      title="Salvar nome da categoria"
                      aria-label="Salvar nome da categoria"
                      className="p-1 rounded bg-[#E31E24] text-white hover:bg-[#B91419] cursor-pointer"
                    >
                      <Check className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setRenamingCatId(null)}
                      title="Cancelar"
                      aria-label="Cancelar edição da categoria"
                      className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </form>
                );
              }

              return (
                <div
                  key={cat.id}
                  className={`inline-flex items-center shrink-0 rounded-md transition-colors ${
                    isCatHidden
                      ? 'border border-dashed border-amber-400/80 dark:border-amber-600/70 bg-amber-50/40 dark:bg-amber-950/20'
                      : ''
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setCategory(cat.id)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                      isCatHidden ? 'line-through opacity-75' : ''
                    } ${
                      active
                        ? 'bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white shadow-xs'
                        : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                    }`}
                  >
                    {cat.label}
                  </button>
                  {canManageModels && (
                    <button
                      type="button"
                      onClick={() => onToggleHiddenCategory(cat.id)}
                      aria-pressed={isCatHidden}
                      title={
                        isCatHidden
                          ? `Categoria "${cat.label}" oculta dos clientes — clique no cadeado para exibir`
                          : `Clique no cadeado para ocultar a categoria "${cat.label}" dos clientes`
                      }
                      aria-label={
                        isCatHidden
                          ? `Exibir categoria ${cat.label} para clientes`
                          : `Ocultar categoria ${cat.label} dos clientes`
                      }
                      className={`p-1 transition-colors cursor-pointer ${
                        isCatHidden
                          ? 'text-amber-600 dark:text-amber-400 hover:text-amber-700'
                          : 'text-zinc-400 hover:text-[#E31E24]'
                      }`}
                    >
                      {isCatHidden ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                    </button>
                  )}
                  {canManageModels && (
                    <button
                      type="button"
                      onClick={() => {
                        setDraftCatLabel(cat.label);
                        setRenamingCatId(cat.id);
                      }}
                      title={`Alterar nome da categoria ${cat.label}`}
                      aria-label={`Alterar nome da categoria ${cat.label}`}
                      className="p-1 text-zinc-400 hover:text-[#E31E24] transition-colors cursor-pointer"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>
                  )}
                  {canManageModels && isCustom && (
                    <button
                      type="button"
                      onClick={() => {
                        if (category === cat.id) setCategory('all');
                        onDeleteCategory(cat.id);
                      }}
                      title={`Remover categoria ${cat.label}`}
                      aria-label={`Remover categoria ${cat.label}`}
                      className="p-1 text-zinc-400 hover:text-[#E31E24] transition-colors cursor-pointer"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <div
            className="flex items-center gap-1 p-1 bg-zinc-100 dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 shrink-0"
            role="group"
            aria-label="Modo de exibição"
          >
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              title="Visualização em grade"
              aria-label="Visualização em grade"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              title="Tabela comparativa"
              aria-label="Tabela comparativa"
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {canManageModels && category !== 'all' && hiddenCategories.has(category) && (
        <div className="mb-4 px-4 py-2.5 rounded-lg border border-dashed border-amber-400/80 dark:border-amber-600/70 bg-amber-50/70 dark:bg-amber-950/20 flex flex-wrap items-center justify-between gap-2 text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2 font-medium">
            <Lock className="w-3.5 h-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
            <span>
              A categoria{' '}
              <strong>
                {allCategories.find((c) => c.id === category)?.label || category}
              </strong>{' '}
              e os modelos dela estão ocultos para os clientes no modo de visualização.
            </span>
          </div>
          <button
            type="button"
            onClick={() => onToggleHiddenCategory(category)}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white transition-colors cursor-pointer"
          >
            <Unlock className="w-3 h-3" />
            Exibir para clientes
          </button>
        </div>
      )}

      {/* Empty State */}
      {filteredModels.length === 0 ? (
        <div className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-10 text-center">
          <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
            Nenhum modelo encontrado para os filtros atuais.
          </p>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
            {canManageModels && category !== 'all'
              ? 'Adicione um novo modelo nesta categoria ou limpe os filtros.'
              : 'Tente limpar a busca ou selecionar outro segmento de motocicleta.'}
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
            {canManageModels && category !== 'all' && (
              <button
                type="button"
                onClick={() => {
                  setSelectedCatChoice(category);
                  setShowAddForm(true);
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-[#E31E24] hover:bg-[#B91419] text-white cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Incluir modelo nesta categoria
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setCategory('all');
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 cursor-pointer"
            >
              Limpar filtros
            </button>
          </div>
        </div>
      ) : viewMode === 'grid' || isEditing ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredModels.map(({ model, originalIndex, resolvedCat }) => {
            const customPhoto = getCustomModelPhoto(data.photos, model.m);
            const photoUrl = customPhoto || getDefaultModelPhoto(model.m);
            return (
              <ModelCard
                key={`${revisionKey}-${originalIndex}`}
                revisionKey={revisionKey}
                modelIndex={originalIndex}
                model={model}
                parts={data.parts}
                categories={allCategories}
                resolvedCategory={resolvedCat}
                photoUrl={photoUrl}
                hasCustomPhoto={Boolean(customPhoto)}
                isAdmin={isAdmin}
                isEditing={isEditing}
                isDragging={draggedModelIndex === originalIndex}
                isDropTarget={
                  dropTargetIndex === originalIndex && draggedModelIndex !== originalIndex
                }
                onDragStartCard={(idx, e) => {
                  setDraggedModelIndex(idx);
                  e.dataTransfer.effectAllowed = 'move';
                  e.dataTransfer.setData('text/plain', String(idx));
                }}
                onDragOverCard={(idx, e) => {
                  if (draggedModelIndex === null) return;
                  e.preventDefault();
                  e.dataTransfer.dropEffect = 'move';
                  if (dropTargetIndex !== idx) {
                    setDropTargetIndex(idx);
                  }
                }}
                onDropCard={(idx, e) => {
                  e.preventDefault();
                  const from =
                    draggedModelIndex !== null
                      ? draggedModelIndex
                      : Number.parseInt(e.dataTransfer.getData('text/plain'), 10);
                  if (!Number.isNaN(from) && from !== idx) {
                    onReorderModels(revisionKey, from, idx);
                  }
                  setDraggedModelIndex(null);
                  setDropTargetIndex(null);
                }}
                onDragEndCard={() => {
                  setDraggedModelIndex(null);
                  setDropTargetIndex(null);
                }}
                onUpdateModelName={onUpdateModelName}
                onUpdateModelCategory={onUpdateModelCategory}
                onRenameCategory={onRenameCategory}
                onUploadPhoto={onUploadPhoto}
                onRemovePhoto={onRemovePhoto}
                onUpdateItemQty={onUpdateItemQty}
                onUpdatePartPrice={onUpdatePartPrice}
                onRemoveItem={onRemoveItem}
                onAddItem={onAddItem}
                onDeleteModel={onDeleteModel}
                onToggleHiddenModel={onToggleHiddenModel}
              />
            );
          })}
        </div>
      ) : (
        /* Compact Comparison Table Mode */
        <div className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/60 text-xs font-semibold text-zinc-600 dark:text-zinc-400">
                  {canManageModels && <th className="py-3 pl-3 pr-1 w-8" aria-label="Organizar" />}
                  <th className="py-3 px-4">Modelo</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Peças incluídas</th>
                  <th className="py-3 px-4 text-right">Total ({revisionKey}ª rev.)</th>
                  <th className="py-3 px-4 text-right">
                    {canManageModels ? 'Visibilidade' : 'Agendamento'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
                {filteredModels.map(({ model, originalIndex, resolvedCat }) => {
                  const total = computeModelTotal(model, data.parts);
                  const summaryItems = model.i
                    .map((it) => {
                      const p = data.parts[it.p];
                      if (!p) return null;
                      return { name: p.n, qty: it.q };
                    })
                    .filter((x): x is { name: string; qty: number } => Boolean(x))
                    .sort((a, b) =>
                      a.name.trim().localeCompare(b.name.trim(), 'pt-BR', { sensitivity: 'base' })
                    );

                  const isRowDragging = draggedModelIndex === originalIndex;
                  const isRowTarget =
                    dropTargetIndex === originalIndex && draggedModelIndex !== originalIndex;

                  return (
                    <tr
                      key={`${revisionKey}-row-${originalIndex}`}
                      draggable={canManageModels}
                      onDragStart={(e) => {
                        if (!canManageModels) return;
                        setDraggedModelIndex(originalIndex);
                        e.dataTransfer.effectAllowed = 'move';
                        e.dataTransfer.setData('text/plain', String(originalIndex));
                      }}
                      onDragOver={(e) => {
                        if (!canManageModels || draggedModelIndex === null) return;
                        e.preventDefault();
                        e.dataTransfer.dropEffect = 'move';
                        if (dropTargetIndex !== originalIndex) {
                          setDropTargetIndex(originalIndex);
                        }
                      }}
                      onDrop={(e) => {
                        if (!canManageModels) return;
                        e.preventDefault();
                        const from =
                          draggedModelIndex !== null
                            ? draggedModelIndex
                            : Number.parseInt(e.dataTransfer.getData('text/plain'), 10);
                        if (!Number.isNaN(from) && from !== originalIndex) {
                          onReorderModels(revisionKey, from, originalIndex);
                        }
                        setDraggedModelIndex(null);
                        setDropTargetIndex(null);
                      }}
                      onDragEnd={() => {
                        setDraggedModelIndex(null);
                        setDropTargetIndex(null);
                      }}
                      className={`transition-colors ${
                        isRowDragging
                          ? 'opacity-50 bg-red-50/40 dark:bg-red-950/20'
                          : isRowTarget
                            ? 'bg-red-50/70 dark:bg-red-950/30 outline-2 outline-[#E31E24]'
                            : 'hover:bg-zinc-50/70 dark:hover:bg-zinc-900/40'
                      }`}
                    >
                      {canManageModels && (
                        <td className="py-3 pl-3 pr-1 text-zinc-400 cursor-grab active:cursor-grabbing">
                          <GripVertical className="w-4 h-4" />
                        </td>
                      )}
                      <td className="py-3 px-4 font-semibold uppercase text-zinc-900 dark:text-zinc-100 whitespace-nowrap">
                        <span className={model.hidden ? 'line-through opacity-60' : ''}>
                          {model.m.trim().toLocaleUpperCase('pt-BR')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-xs text-zinc-500 dark:text-zinc-400 whitespace-nowrap">
                        {resolvedCat.label}
                      </td>
                      <td className="py-3 px-4 text-xs text-zinc-600 dark:text-zinc-300 max-w-md">
                        {summaryItems.map((item, sIdx) => (
                          <React.Fragment key={sIdx}>
                            {sIdx > 0 && ' · '}
                            <PartNameText name={item.name} />
                            {item.qty > 1 ? ` (${item.qty}x)` : ''}
                          </React.Fragment>
                        ))}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-[#E31E24] whitespace-nowrap">
                        {formatBRL(total)}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {canManageModels ? (
                          <button
                            type="button"
                            onClick={() => onToggleHiddenModel(revisionKey, originalIndex)}
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold border transition-colors cursor-pointer ${
                              model.hidden
                                ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-400 dark:border-amber-600 text-amber-800 dark:text-amber-300'
                                : 'border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:border-[#E31E24] hover:text-[#E31E24]'
                            }`}
                          >
                            {model.hidden ? (
                              <Lock className="w-3 h-3" />
                            ) : (
                              <Unlock className="w-3 h-3" />
                            )}
                            <span>{model.hidden ? 'Oculto' : 'Ocultar'}</span>
                          </button>
                        ) : (
                          <a
                            href={buildWhatsAppUrl(
                              `Olá! Gostaria de agendar a ${revisionKey}ª revisão da minha ${model.m.trim().toLocaleUpperCase('pt-BR')} (valor estimado: ${formatBRL(total)}).`
                            )}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:text-[#E31E24] underline underline-offset-2"
                          >
                            Agendar
                          </a>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </section>
  );
};
