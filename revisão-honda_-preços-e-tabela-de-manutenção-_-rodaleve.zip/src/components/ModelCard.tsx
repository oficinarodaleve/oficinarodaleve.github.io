import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  GripVertical,
  ListChecks,
  Lock,
  Pencil,
  Plus,
  Trash2,
  CalendarCheck,
  Unlock,
  Upload,
  X,
} from 'lucide-react';
import type { CategoryDef, MaintenanceData, ModelRevision } from '../types';
import {
  buildWhatsAppUrl,
  computeModelTotal,
  formatBRL,
} from '../utils/maintenance';
import { MotoPlaceholder } from './MotoPlaceholder';
import { PartNameText } from './PartNameText';

interface ModelCardProps {
  revisionKey: string;
  modelIndex: number;
  model: ModelRevision;
  parts: MaintenanceData['parts'];
  categories: CategoryDef[];
  resolvedCategory: CategoryDef;
  photoUrl?: string;
  hasCustomPhoto?: boolean;
  isAdmin: boolean;
  isEditing: boolean;
  isDragging?: boolean;
  isDropTarget?: boolean;
  onDragStartCard?: (modelIndex: number, e: React.DragEvent<HTMLElement>) => void;
  onDragOverCard?: (modelIndex: number, e: React.DragEvent<HTMLElement>) => void;
  onDropCard?: (modelIndex: number, e: React.DragEvent<HTMLElement>) => void;
  onDragEndCard?: () => void;
  onUpdateModelName: (revKey: string, modelIndex: number, newName: string) => void;
  onUpdateModelCategory: (revKey: string, modelIndex: number, categoryId: string) => void;
  onRenameCategory: (categoryId: string, newLabel: string) => void;
  onUploadPhoto: (modelName: string, file: File) => void;
  onRemovePhoto: (modelName: string) => void;
  onUpdateItemQty: (revKey: string, modelIndex: number, itemIndex: number, qty: number) => void;
  onUpdatePartPrice: (partId: string, price: number) => void;
  onRemoveItem: (revKey: string, modelIndex: number, itemIndex: number) => void;
  onAddItem: (revKey: string, modelIndex: number, partId: string) => void;
  onDeleteModel: (revKey: string, modelIndex: number) => void;
  onToggleHiddenModel: (revKey: string, modelIndex: number) => void;
}

export const ModelCard: React.FC<ModelCardProps> = ({
  revisionKey,
  modelIndex,
  model,
  parts,
  categories,
  resolvedCategory,
  photoUrl,
  hasCustomPhoto = false,
  isAdmin,
  isEditing,
  isDragging = false,
  isDropTarget = false,
  onDragStartCard,
  onDragOverCard,
  onDropCard,
  onDragEndCard,
  onUpdateModelName,
  onUpdateModelCategory,
  onRenameCategory,
  onUploadPhoto,
  onRemovePhoto,
  onUpdateItemQty,
  onUpdatePartPrice,
  onRemoveItem,
  onAddItem,
  onDeleteModel,
  onToggleHiddenModel,
}) => {
  const partIds = useMemo(
    () =>
      Object.keys(parts).sort((a, b) =>
        parts[a].n.trim().localeCompare(parts[b].n.trim(), 'pt-BR', { sensitivity: 'base' })
      ),
    [parts]
  );
  const [selectedPartId, setSelectedPartId] = useState<string>(partIds[0] || '');
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [isRenaming, setIsRenaming] = useState(false);
  const [draftName, setDraftName] = useState(model.m);
  const [isRenamingCategory, setIsRenamingCategory] = useState(false);
  const [draftCatLabel, setDraftCatLabel] = useState(resolvedCategory.label);
  const [showPartsChecklist, setShowPartsChecklist] = useState(false);
  const [partFilterQuery, setPartFilterQuery] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const allowDragRef = useRef(true);

  const effectiveSelectedPartId = parts[selectedPartId] ? selectedPartId : partIds[0] || '';

  const sortedModelItems = useMemo(
    () =>
      model.i
        .map((item, originalItemIdx) => ({
          item,
          originalItemIdx,
          part: parts[item.p],
        }))
        .filter((entry) => Boolean(entry.part))
        .sort((a, b) =>
          a.part.n.trim().localeCompare(b.part.n.trim(), 'pt-BR', { sensitivity: 'base' })
        ),
    [model.i, parts]
  );

  const filteredChecklistIds = useMemo(() => {
    const q = partFilterQuery.trim().toLowerCase();
    if (!q) return partIds;
    return partIds.filter((id) => {
      const p = parts[id];
      return p.n.toLowerCase().includes(q) || p.c.toLowerCase().includes(q);
    });
  }, [partIds, parts, partFilterQuery]);

  useEffect(() => {
    setDraftName(model.m);
  }, [model.m]);

  useEffect(() => {
    setDraftCatLabel(resolvedCategory.label);
  }, [resolvedCategory.label]);

  const total = computeModelTotal(model, parts);
  const itemCount = model.i.filter((it) => Boolean(parts[it.p])).length;

  const upperModelName = model.m.trim().toLocaleUpperCase('pt-BR');

  const scheduleUrl = buildWhatsAppUrl(
    `Olá! Gostaria de agendar a ${revisionKey}ª revisão da minha ${upperModelName} (valor estimado: ${formatBRL(total)}).`
  );

  const canManagePhoto = isAdmin || isEditing;
  const isModelHidden = Boolean(model.hidden);

  return (
    <article
      draggable={canManagePhoto && !isRenaming && !isRenamingCategory}
      onMouseDown={(e) => {
        if (!canManagePhoto) return;
        const target = e.target as HTMLElement;
        allowDragRef.current = !target.closest(
          'input, select, textarea, a, button:not([data-drag-handle])'
        );
      }}
      onDragStart={(e) => {
        if (!canManagePhoto || !allowDragRef.current) {
          e.preventDefault();
          return;
        }
        onDragStartCard?.(modelIndex, e);
      }}
      onDragOver={(e) => {
        if (!canManagePhoto) return;
        onDragOverCard?.(modelIndex, e);
      }}
      onDrop={(e) => {
        if (!canManagePhoto) return;
        onDropCard?.(modelIndex, e);
      }}
      onDragEnd={() => onDragEndCard?.()}
      className={`bg-white dark:bg-[#16161A] border rounded-xl overflow-hidden flex flex-col transition-all ${
        isDragging
          ? 'opacity-50 scale-[0.98] border-[#E31E24] ring-2 ring-[#E31E24]/40'
          : isDropTarget
            ? 'border-[#E31E24] ring-2 ring-[#E31E24] shadow-md'
            : isModelHidden && canManagePhoto
              ? 'border-dashed border-amber-400 dark:border-amber-600/80 opacity-85 hover:opacity-100'
              : 'border-zinc-200 dark:border-zinc-800 hover:shadow-sm'
      }`}
    >
      {/* Manager-only Bar above the model photo (Drag Handle + Photo Import + Hide Toggle) */}
      {canManagePhoto && (
        <div className="px-3.5 py-2 bg-zinc-50 dark:bg-zinc-900/80 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2.5">
            <span
              data-drag-handle="true"
              title="Arraste para reorganizar a ordem deste modelo"
              className="inline-flex items-center gap-1 text-[11px] font-semibold text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white cursor-grab active:cursor-grabbing select-none pr-2 border-r border-zinc-200 dark:border-zinc-700"
            >
              <GripVertical className="w-3.5 h-3.5 text-zinc-400" />
              <span>Arrastar</span>
            </span>

            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-1 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:text-[#E31E24] dark:hover:text-[#E31E24] transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-[#E31E24]" />
              <span>{photoUrl ? 'Trocar foto' : 'Importar foto'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {hasCustomPhoto && (
              <button
                type="button"
                onClick={() => onRemovePhoto(model.m)}
                title="Restaurar foto padrão"
                className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-[#E31E24] transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remover</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => onToggleHiddenModel(revisionKey, modelIndex)}
              aria-pressed={isModelHidden}
              title={
                isModelHidden
                  ? 'Modelo oculto dos clientes — clique para exibir'
                  : 'Ocultar este modelo dos clientes'
              }
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold border transition-colors cursor-pointer ${
                isModelHidden
                  ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-400 dark:border-amber-600 text-amber-800 dark:text-amber-300 hover:bg-amber-200 dark:hover:bg-amber-900/60'
                  : 'border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:border-[#E31E24] hover:text-[#E31E24]'
              }`}
            >
              {isModelHidden ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
              <span>{isModelHidden ? 'Oculto' : 'Ocultar'}</span>
            </button>
          </div>

          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                onUploadPhoto(model.m, file);
                e.target.value = '';
              }
            }}
          />
        </div>
      )}

      {/* Photo Slot */}
      <div
        onClick={canManagePhoto ? () => fileRef.current?.click() : undefined}
        className={`relative aspect-[4/3] border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-center overflow-hidden ${
          photoUrl ? 'bg-white' : 'bg-zinc-50 dark:bg-zinc-900/70'
        } ${
          canManagePhoto ? 'cursor-pointer hover:opacity-95 transition-opacity' : ''
        }`}
      >
        {photoUrl ? (
          <img
            src={photoUrl}
            alt={model.m.trim()}
            draggable={false}
            className="w-full h-full object-contain p-2 select-none"
            referrerPolicy="no-referrer"
          />
        ) : (
          <MotoPlaceholder modelName={model.m} />
        )}
      </div>

      {/* Header & Metadata */}
      <div className="px-5 pt-4 pb-2">
        {isEditing ? (
          <input
            type="text"
            value={model.m}
            onChange={(e) =>
              onUpdateModelName(revisionKey, modelIndex, e.target.value.toLocaleUpperCase('pt-BR'))
            }
            aria-label="Nome do modelo"
            className="w-full px-2.5 py-1.5 text-base font-bold uppercase rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
          />
        ) : isAdmin && isRenaming ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const clean = draftName.trim().toLocaleUpperCase('pt-BR');
              if (clean) {
                onUpdateModelName(revisionKey, modelIndex, clean);
              } else {
                setDraftName(upperModelName);
              }
              setIsRenaming(false);
            }}
            className="flex items-center gap-1.5"
          >
            <input
              type="text"
              autoFocus
              value={draftName}
              onChange={(e) => setDraftName(e.target.value.toLocaleUpperCase('pt-BR'))}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setDraftName(upperModelName);
                  setIsRenaming(false);
                }
              }}
              aria-label="Novo nome do modelo"
              className="flex-1 min-w-0 px-2.5 py-1.5 text-base font-bold uppercase rounded-lg border border-[#E31E24] bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none"
            />
            <button
              type="submit"
              title="Salvar nome"
              aria-label="Salvar nome do modelo"
              className="p-1.5 rounded-lg bg-[#E31E24] text-white hover:bg-[#B91419] transition-colors cursor-pointer shrink-0"
            >
              <Check className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => {
                setDraftName(model.m);
                setIsRenaming(false);
              }}
              title="Cancelar"
              aria-label="Cancelar edição do nome"
              className="p-1.5 rounded-lg border border-zinc-200 dark:border-zinc-700 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition-colors cursor-pointer shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <div className="flex items-start justify-between gap-2">
            <h2 className="text-lg font-bold tracking-tight uppercase text-zinc-900 dark:text-zinc-100 leading-snug">
              {upperModelName}
            </h2>
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  setDraftName(upperModelName);
                  setIsRenaming(true);
                }}
                title="Alterar nome do modelo"
                aria-label={`Alterar nome de ${upperModelName}`}
                className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-medium text-zinc-500 dark:text-zinc-400 border border-zinc-200 dark:border-zinc-700 hover:border-[#E31E24] hover:text-[#E31E24] transition-colors shrink-0 cursor-pointer"
              >
                <Pencil className="w-3 h-3" />
                <span>Editar</span>
              </button>
            )}
          </div>
        )}
        <div className="mt-1.5 flex items-center flex-wrap gap-2 text-xs text-zinc-500 dark:text-zinc-400">
          {canManagePhoto ? (
            isRenamingCategory ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const clean = draftCatLabel.trim();
                  if (clean) {
                    onRenameCategory(resolvedCategory.id, clean);
                  } else {
                    setDraftCatLabel(resolvedCategory.label);
                  }
                  setIsRenamingCategory(false);
                }}
                className="inline-flex items-center gap-1"
              >
                <input
                  type="text"
                  autoFocus
                  value={draftCatLabel}
                  onChange={(e) => setDraftCatLabel(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') {
                      setDraftCatLabel(resolvedCategory.label);
                      setIsRenamingCategory(false);
                    }
                  }}
                  aria-label="Novo nome da categoria"
                  className="w-36 px-2 py-0.5 text-xs font-medium rounded-md border border-[#E31E24] bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none"
                />
                <button
                  type="submit"
                  title="Salvar nome da categoria"
                  aria-label="Salvar nome da categoria"
                  className="p-1 rounded bg-[#E31E24] text-white hover:bg-[#B91419] transition-colors cursor-pointer"
                >
                  <Check className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDraftCatLabel(resolvedCategory.label);
                    setIsRenamingCategory(false);
                  }}
                  title="Cancelar"
                  aria-label="Cancelar edição da categoria"
                  className="p-1 rounded border border-zinc-200 dark:border-zinc-700 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition-colors cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </form>
            ) : (
              <div className="inline-flex items-center gap-1">
                <select
                  value={resolvedCategory.id}
                  onChange={(e) => onUpdateModelCategory(revisionKey, modelIndex, e.target.value)}
                  aria-label={`Categoria de ${model.m.trim()}`}
                  className="px-2 py-0.5 text-xs font-medium rounded-md border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-700 dark:text-zinc-200 focus:outline-none focus:border-[#E31E24] cursor-pointer"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    setDraftCatLabel(resolvedCategory.label);
                    setIsRenamingCategory(true);
                  }}
                  title={`Alterar nome da categoria "${resolvedCategory.label}"`}
                  aria-label={`Alterar nome da categoria ${resolvedCategory.label}`}
                  className="p-1 rounded border border-zinc-200 dark:border-zinc-700 text-zinc-400 hover:text-[#E31E24] hover:border-[#E31E24] transition-colors cursor-pointer"
                >
                  <Pencil className="w-3 h-3" />
                </button>
              </div>
            )
          ) : (
            <span>{resolvedCategory.label}</span>
          )}
          <span aria-hidden="true">·</span>
          <span>
            {itemCount} {itemCount === 1 ? 'item' : 'itens'}
          </span>
        </div>
      </div>

      {/* Parts List (Alphabetical) */}
      <ul className="px-5 py-2 flex-1 divide-y divide-zinc-100 dark:divide-zinc-800/80">
        {sortedModelItems.map(({ item, originalItemIdx, part }) => {
          const subtotal = part.p * item.q;

          return (
            <li
              key={`${item.p}-${originalItemIdx}`}
              className="py-2.5 flex items-center justify-between gap-3 text-sm"
            >
              <div className="min-w-0 flex-1">
                <p className="font-medium text-zinc-800 dark:text-zinc-200 leading-snug">
                  <PartNameText name={part.n} />
                  {item.q > 1 && !isEditing && (
                    <span className="ml-1.5 text-xs font-semibold text-zinc-500 dark:text-zinc-400">
                      ({item.q} un.)
                    </span>
                  )}
                </p>
                <p className="text-[11px] font-mono text-zinc-500 dark:text-zinc-400 mt-0.5">
                  Cód. {part.c || '—'}
                </p>
              </div>

              {isEditing ? (
                <div className="flex items-center gap-1.5 shrink-0">
                  <input
                    type="number"
                    min={1}
                    step={1}
                    value={item.q}
                    aria-label="Quantidade"
                    onChange={(e) =>
                      onUpdateItemQty(
                        revisionKey,
                        modelIndex,
                        originalItemIdx,
                        Math.max(1, parseInt(e.target.value, 10) || 1)
                      )
                    }
                    className="w-12 px-1.5 py-1 text-xs font-mono tabular-nums text-center rounded border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100"
                  />
                  <input
                    type="number"
                    min={0}
                    step="0.01"
                    value={part.p}
                    aria-label="Valor unitário"
                    onChange={(e) =>
                      onUpdatePartPrice(item.p, Math.max(0, parseFloat(e.target.value) || 0))
                    }
                    className="w-20 px-1.5 py-1 text-xs font-mono tabular-nums text-right rounded border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100"
                  />
                  <button
                    type="button"
                    onClick={() => onRemoveItem(revisionKey, modelIndex, originalItemIdx)}
                    aria-label={`Remover ${part.n}`}
                    title="Remover peça deste modelo"
                    className="p-1 text-zinc-400 hover:text-[#E31E24] transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : canManagePhoto ? (
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-mono tabular-nums text-sm font-semibold text-zinc-900 dark:text-zinc-100 whitespace-nowrap">
                    {formatBRL(subtotal)}
                  </span>
                  <button
                    type="button"
                    onClick={() => onRemoveItem(revisionKey, modelIndex, originalItemIdx)}
                    aria-label={`Remover ${part.n}`}
                    title="Remover peça deste modelo"
                    className="p-1 rounded text-zinc-400 hover:text-[#E31E24] hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <span className="font-mono tabular-nums text-sm font-semibold text-zinc-900 dark:text-zinc-100 whitespace-nowrap shrink-0">
                  {formatBRL(subtotal)}
                </span>
              )}
            </li>
          );
        })}

        {model.i.length === 0 && (
          <li className="py-6 text-center text-xs text-zinc-400 dark:text-zinc-500">
            Nenhuma peça vinculada a este modelo.
          </li>
        )}
      </ul>

      {/* Manager Parts Inclusion / Selection Controls */}
      {canManagePhoto && (
        <div className="px-5 py-3 bg-zinc-50 dark:bg-zinc-900/50 border-t border-zinc-200 dark:border-zinc-800 space-y-2.5">
          <div className="flex items-center gap-2">
            <select
              value={effectiveSelectedPartId}
              onChange={(e) => setSelectedPartId(e.target.value)}
              aria-label="Selecionar peça para adicionar"
              className="flex-1 min-w-0 px-2.5 py-1.5 text-xs rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-800 dark:text-zinc-100"
            >
              {partIds.map((id) => (
                <option key={id} value={id}>
                  {parts[id].n} ({formatBRL(parts[id].p)})
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() =>
                effectiveSelectedPartId && onAddItem(revisionKey, modelIndex, effectiveSelectedPartId)
              }
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 hover:opacity-90 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Incluir peça
            </button>
          </div>

          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => setShowPartsChecklist((v) => !v)}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:text-[#E31E24] transition-colors cursor-pointer"
            >
              <ListChecks className="w-3.5 h-3.5 text-[#E31E24]" />
              <span>
                {showPartsChecklist ? 'Fechar lista de peças' : 'Selecionar peças (marcar/desmarcar)'}
              </span>
            </button>

            {!confirmDelete ? (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="text-xs font-medium text-zinc-500 hover:text-[#E31E24] transition-colors cursor-pointer"
              >
                Excluir modelo
              </button>
            ) : (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-zinc-600 dark:text-zinc-300">Confirmar exclusão?</span>
                <button
                  type="button"
                  onClick={() => {
                    onDeleteModel(revisionKey, modelIndex);
                    setConfirmDelete(false);
                  }}
                  className="px-2 py-0.5 bg-[#E31E24] text-white font-semibold rounded cursor-pointer"
                >
                  Excluir
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="px-2 py-0.5 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 cursor-pointer"
                >
                  Cancelar
                </button>
              </div>
            )}
          </div>

          {showPartsChecklist && (
            <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 space-y-2">
              <input
                type="search"
                value={partFilterQuery}
                onChange={(e) => setPartFilterQuery(e.target.value)}
                placeholder="Filtrar peça por nome ou código…"
                aria-label="Filtrar peça do catálogo"
                className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
              />
              <div className="max-h-48 overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950/60">
                {filteredChecklistIds.map((partId) => {
                  const p = parts[partId];
                  const existingIdx = model.i.findIndex((it) => it.p === partId);
                  const checked = existingIdx !== -1;
                  return (
                    <label
                      key={partId}
                      className="flex items-center justify-between gap-2 px-2.5 py-1.5 text-xs hover:bg-zinc-50 dark:hover:bg-zinc-900/60 cursor-pointer select-none"
                    >
                      <span className="flex items-center gap-2 min-w-0">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => {
                            if (checked) {
                              onRemoveItem(revisionKey, modelIndex, existingIdx);
                            } else {
                              onAddItem(revisionKey, modelIndex, partId);
                            }
                          }}
                          className="rounded border-zinc-300 text-[#E31E24] focus:ring-[#E31E24] shrink-0"
                        />
                        <span className="truncate text-zinc-800 dark:text-zinc-200">
                          <PartNameText name={p.n} />
                        </span>
                      </span>
                      <span className="font-mono tabular-nums text-[11px] text-zinc-500 dark:text-zinc-400 shrink-0">
                        {formatBRL(p.p)}
                      </span>
                    </label>
                  );
                })}
                {filteredChecklistIds.length === 0 && (
                  <p className="py-3 text-center text-xs text-zinc-400">
                    Nenhuma peça encontrada.
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Total Bar */}
      <div className="bg-[#E31E24] text-white px-5 py-3.5 flex items-center justify-between gap-4">
        <span className="text-xs font-medium uppercase tracking-wider text-white/90">
          Total da {revisionKey}ª revisão
        </span>
        <span className="font-mono tabular-nums text-lg font-bold">
          {formatBRL(total)}
        </span>
      </div>

      {/* Customer Action Strip */}
      {!isEditing && (
        <a
          href={scheduleUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="px-5 py-2.5 bg-zinc-50 dark:bg-zinc-900/60 border-t border-zinc-200 dark:border-zinc-800 text-xs font-semibold text-zinc-700 dark:text-zinc-300 hover:text-[#E31E24] dark:hover:text-[#E31E24] flex items-center justify-between transition-colors"
        >
          <span>Agendar {revisionKey}ª revisão desta moto</span>
          <CalendarCheck className="w-4 h-4 shrink-0" />
        </a>
      )}
    </article>
  );
};
