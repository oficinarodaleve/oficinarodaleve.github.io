import React, { useState } from 'react';
import { ChevronDown, Plus, Trash2 } from 'lucide-react';
import type { FaqItem } from '../types';

interface FaqSectionProps {
  faq: FaqItem[];
  isAdmin: boolean;
  isEditing: boolean;
  onAddFaq: (q: string, a: string) => void;
  onUpdateFaq: (index: number, field: 'q' | 'a', value: string) => void;
  onDeleteFaq: (index: number) => void;
}

export const FaqSection: React.FC<FaqSectionProps> = ({
  faq,
  isAdmin,
  isEditing,
  onAddFaq,
  onUpdateFaq,
  onDeleteFaq,
}) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [newQuestion, setNewQuestion] = useState('');
  const [newAnswer, setNewAnswer] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const canManageFaq = isAdmin || isEditing;

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = newQuestion.trim();
    const a = newAnswer.trim();
    if (!q || !a) {
      setFormError('Preencha a pergunta e a resposta antes de adicionar.');
      return;
    }
    onAddFaq(q, a);
    setNewQuestion('');
    setNewAnswer('');
    setFormError(null);
  };

  return (
    <section className="max-w-3xl space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white">
            Perguntas Frequentes
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            Informações sobre revisões programadas, garantia Honda e peças genuínas.
          </p>
        </div>
        <span className="text-xs font-medium text-zinc-500 dark:text-zinc-400 shrink-0">
          {faq.length} {faq.length === 1 ? 'pergunta' : 'perguntas'}
        </span>
      </div>

      {canManageFaq && (
        <form
          onSubmit={handleCreateSubmit}
          className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 space-y-3.5 shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
              Criar nova pergunta e resposta
            </h3>
            <span className="text-[11px] font-medium text-zinc-500 dark:text-zinc-400">
              Área do gestor
            </span>
          </div>

          <div className="space-y-1.5">
            <label
              htmlFor="new-faq-question"
              className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
            >
              Pergunta
            </label>
            <input
              id="new-faq-question"
              type="text"
              value={newQuestion}
              onChange={(e) => {
                setNewQuestion(e.target.value);
                if (formError) setFormError(null);
              }}
              placeholder="Ex: Qual o prazo de garantia da revisão?"
              className="w-full px-3 py-2 text-sm rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
            />
          </div>

          <div className="space-y-1.5">
            <label
              htmlFor="new-faq-answer"
              className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
            >
              Resposta
            </label>
            <textarea
              id="new-faq-answer"
              value={newAnswer}
              onChange={(e) => {
                setNewAnswer(e.target.value);
                if (formError) setFormError(null);
              }}
              placeholder="Digite a resposta completa que será exibida aos clientes..."
              rows={3}
              className="w-full px-3 py-2 text-sm rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-800 dark:text-zinc-200 focus:outline-none focus:border-[#E31E24]"
            />
          </div>

          {formError && (
            <p className="text-xs font-medium text-[#E31E24]">{formError}</p>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold bg-[#E31E24] hover:bg-[#B91419] text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Adicionar pergunta
            </button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {faq.map((item, idx) => {
          if (canManageFaq) {
            return (
              <div
                key={idx}
                className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
                    Pergunta {idx + 1}
                  </span>
                  <button
                    type="button"
                    onClick={() => onDeleteFaq(idx)}
                    className="inline-flex items-center gap-1 text-xs text-zinc-500 hover:text-[#E31E24] cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Excluir
                  </button>
                </div>
                <input
                  type="text"
                  value={item.q}
                  onChange={(e) => onUpdateFaq(idx, 'q', e.target.value)}
                  placeholder="Título da pergunta"
                  className="w-full px-3 py-2 text-sm font-semibold rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-white focus:outline-none focus:border-[#E31E24]"
                />
                <textarea
                  value={item.a}
                  onChange={(e) => onUpdateFaq(idx, 'a', e.target.value)}
                  placeholder="Resposta"
                  rows={3}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-700 dark:text-zinc-200 focus:outline-none focus:border-[#E31E24]"
                />
              </div>
            );
          }

          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden"
            >
              <button
                type="button"
                aria-expanded={isOpen}
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full px-5 py-4 flex items-center justify-between gap-4 text-left font-semibold text-sm sm:text-base text-zinc-900 dark:text-zinc-100 hover:bg-zinc-50 dark:hover:bg-zinc-900/40 transition-colors cursor-pointer"
              >
                <span>{item.q}</span>
                <ChevronDown
                  className={`w-4 h-4 text-zinc-400 shrink-0 transition-transform ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {isOpen && (
                <div className="px-5 pb-4 pt-1 text-sm text-zinc-600 dark:text-zinc-400 whitespace-pre-wrap leading-relaxed border-t border-zinc-100 dark:border-zinc-800/80">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}

        {faq.length === 0 && (
          <div className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-8 text-center text-xs text-zinc-500">
            Nenhuma pergunta cadastrada.
          </div>
        )}
      </div>
    </section>
  );
};
