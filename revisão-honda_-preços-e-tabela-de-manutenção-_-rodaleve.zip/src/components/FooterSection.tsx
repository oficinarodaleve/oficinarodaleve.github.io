import React from 'react';
import { Moon, Settings, Sun } from 'lucide-react';
import { buildWhatsAppUrl, WHATSAPP_DISPLAY } from '../utils/maintenance';

interface FooterSectionProps {
  isDark: boolean;
  onToggleTheme: () => void;
  isAdmin: boolean;
  onToggleAdmin: () => void;
}

export const FooterSection: React.FC<FooterSectionProps> = ({
  isDark,
  onToggleTheme,
  isAdmin,
  onToggleAdmin,
}) => {
  return (
    <footer className="bg-white dark:bg-[#121215] border-t border-zinc-200 dark:border-zinc-800 mt-6">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
        {/* Column 1: Brand, Social & Theme/Admin Controls */}
        <div className="space-y-4">
          <div className="inline-flex rounded-md dark:bg-white dark:px-2.5 dark:py-1">
            <img
              src="/rodaleve-logo.png"
              alt="Rodaleve"
              className="h-9 w-auto object-contain"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              Siga nossas redes sociais
            </p>
            <div className="flex items-center gap-2">
              <a
                href="https://www.instagram.com/rodaleve/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="w-8 h-8 rounded bg-[#B30000] hover:bg-[#E31E24] transition-colors flex items-center justify-center"
              >
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#fff"
                  strokeWidth="2"
                  aria-hidden="true"
                >
                  <rect x="3" y="3" width="18" height="18" rx="5" />
                  <circle cx="12" cy="12" r="4" />
                  <circle cx="17.3" cy="6.7" r=".8" fill="#fff" />
                </svg>
              </a>
              <a
                href="https://www.youtube.com/@rodalevehonda"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube"
                className="w-8 h-8 rounded bg-[#B30000] hover:bg-[#E31E24] transition-colors flex items-center justify-center"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
                  <rect x="2" y="5" width="20" height="14" rx="4" fill="#fff" />
                  <path d="M10 9l5 3-5 3z" fill="#b30000" />
                </svg>
              </a>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              onClick={onToggleTheme}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 hover:border-zinc-300 dark:hover:border-zinc-600 transition-colors cursor-pointer"
            >
              {isDark ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              <span>{isDark ? 'Tema claro' : 'Tema escuro'}</span>
            </button>

            <button
              type="button"
              onClick={onToggleAdmin}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                isAdmin
                  ? 'border-[#E31E24] text-[#E31E24]'
                  : 'border-zinc-200 dark:border-zinc-700 text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>{isAdmin ? 'Gestor ativo' : 'Área do gestor'}</span>
            </button>
          </div>
        </div>

        {/* Column 2: Opening Hours */}
        <div className="space-y-2 text-sm text-zinc-600 dark:text-zinc-400">
          <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
            Horários de Funcionamento
          </h3>
          <p>Segunda à sexta-feira: 07h30 às 18h</p>
          <p>Sábado: 07h30 às 12h</p>
          <p className="pt-1">
            WhatsApp:{' '}
            <a
              href={buildWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-zinc-900 dark:text-zinc-200 hover:text-[#E31E24] underline underline-offset-2"
            >
              {WHATSAPP_DISPLAY}
            </a>
          </p>
          <p className="text-xs text-zinc-500 dark:text-zinc-500 pt-1">
            Valores sujeitos a alteração sem aviso prévio.
          </p>
        </div>

        {/* Column 3: Legal & Terms */}
        <div className="space-y-2 text-sm">
          <h3 className="text-sm font-bold text-zinc-900 dark:text-white">
            Políticas e Termos
          </h3>
          <ul className="space-y-1.5 text-zinc-600 dark:text-zinc-400">
            <li>
              <a
                href="https://www.honda.com.br/politica-de-privacidade"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#E31E24] underline underline-offset-2"
              >
                Política de Privacidade
              </a>
            </li>
            <li>
              <a
                href="https://www.honda.com.br/termos-de-uso"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#E31E24] underline underline-offset-2"
              >
                Termos de Uso
              </a>
            </li>
            <li className="text-xs text-zinc-500 dark:text-zinc-500 pt-1">
              Mapas e rotas integrados com Google Maps Platform, sujeitos aos{' '}
              <a
                href="https://maps.google.com/help/terms_maps/"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-zinc-800 dark:hover:text-zinc-300"
              >
                Termos de Serviço do Google Maps
              </a>{' '}
              e{' '}
              <a
                href="https://policies.google.com/privacy"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-zinc-800 dark:hover:text-zinc-300"
              >
                Privacidade do Google
              </a>
              .
            </li>
          </ul>
        </div>
      </div>

      {/* Bottom Safety Campaign Bar */}
      <div className="bg-zinc-100 dark:bg-zinc-900 border-t border-zinc-200 dark:border-zinc-800 py-4">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4">
          <span className="text-xs font-semibold tracking-wide text-zinc-600 dark:text-zinc-400">
            DESACELERE. SEU BEM MAIOR É A VIDA.
          </span>
          <div className="inline-flex rounded dark:bg-white dark:px-2 dark:py-0.5">
            <img
              src="/rodaleve-logo.png"
              alt="Rodaleve"
              className="h-6 w-auto object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 mt-3 pt-3 border-t border-zinc-200/80 dark:border-zinc-800 text-center">
          <p className="text-xs text-zinc-500 dark:text-zinc-400">
            Site Criado por{' '}
            <a
              href="https://wa.me/5577981677591"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-zinc-700 dark:text-zinc-200 hover:text-[#E31E24] underline underline-offset-2 transition-colors"
            >
              Zarvic Marketing
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
};
