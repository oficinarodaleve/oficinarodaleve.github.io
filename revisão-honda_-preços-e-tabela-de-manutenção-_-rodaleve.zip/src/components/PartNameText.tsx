import React from 'react';

interface PartNameTextProps {
  name: string;
}

export const PartNameText: React.FC<PartNameTextProps> = ({ name }) => {
  const segments = name.split(/(\[\s*opcional\s*\])/gi);
  if (segments.length === 1) {
    return <>{name}</>;
  }

  return (
    <>
      {segments.map((segment, idx) =>
        /^\[\s*opcional\s*\]$/i.test(segment) ? (
          <strong key={idx} className="font-bold text-[#E31E24]">
            {segment}
          </strong>
        ) : (
          <React.Fragment key={idx}>{segment}</React.Fragment>
        )
      )}
    </>
  );
};
