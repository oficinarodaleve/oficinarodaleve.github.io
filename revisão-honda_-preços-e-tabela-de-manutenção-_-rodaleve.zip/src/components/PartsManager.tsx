import React, { useMemo, useState } from 'react';
import { Plus, Search, Trash2 } from 'lucide-react';
import type { MaintenanceData } from '../types';
import { PartNameText } from './PartNameText';

interface PartsManagerProps {
  data: MaintenanceData;
  onAddPart: () => void;
  onUpdatePart: (partId: string, field: 'n' | 'c' | 'p', value: string | number) => void;
  onDeletePart: (partId: string) => void;
}

export const PartsManager: React.FC<PartsManagerProps> = ({
  data,
  onAddPart,
  onUpdatePart,
  onDeletePart,
}) => {
  const [search, setSearch] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [editingNameId, setEditingNameId] = useState<string | null>(null);

  const usageCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const revKey of Object.keys(data.revs)) {
      for (const model of data.revs[revKey]) {
        for (const item of model.i) {
          counts[item.p] = (counts[item.p] || 0) + 1;
        }
      }
    }
    return counts;
  }, [data.revs]);

  const partIds = useMemo(() => {
    const q = search.trim().toLowerCase();
    return Object.keys(data.parts).filter((id) => {
      if (!q) return true;
      const p = data.parts[id];
      return p.n.toLowerCase().includes(q) || p.c.toLowerCase().includes(q);
    });
  }, [data.parts, search]);

  return (
    <section className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-zinc-900 dark:text-white">
            Catálogo Central de Peças e Preços
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            Altere o valor unitário aqui e ele será recalculado automaticamente em todas as revisões e modelos.
          </p>
        </div>
        <button
          type="button"
          onClick={onAddPart}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold bg-[#E31E24] hover:bg-[#B91419] text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Nova peça
        </button>
      </div>

      <div className="relative max-w-sm">
        <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filtrar por nome ou código…"
          aria-label="Filtrar peças"
          className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-[#16161A] text-zinc-900 dark:text-zinc-100 focus:outline-none focus:border-[#E31E24]"
        />
      </div>

      <div className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/60 text-xs font-semibold text-zinc-600 dark:text-zinc-400">
                <th className="py-3 px-4">Peça</th>
                <th className="py-3 px-4">Código Honda</th>
                <th className="py-3 px-4 text-right">Valor unit. (R$)</th>
                <th className="py-3 px-4 text-right">Vínculos</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {partIds.map((id) => {
                const part = data.parts[id];
                const uses = usageCounts[id] || 0;
                const confirming = confirmDeleteId === id;

                return (
                  <tr key={id} className="hover:bg-zinc-50/60 dark:hover:bg-zinc-900/40">
                    <td className="py-2.5 px-4 min-w-[220px]">
                      {editingNameId === id ? (
                        <input
                          type="text"
                          autoFocus
                          value={part.n}
                          onChange={(e) => onUpdatePart(id, 'n', e.target.value)}
                          onBlur={() => setEditingNameId(null)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === 'Escape') {
                              setEditingNameId(null);
                            }
                          }}
                          aria-label={`Nome da peça ${part.n}`}
                          className="w-full px-2.5 py-1.5 text-sm rounded-md border border-[#E31E24] bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 focus:outline-none"
                        />
                      ) : (
                        <button
                          type="button"
                          onClick={() => setEditingNameId(id)}
                          aria-label={`Editar nome da peça ${part.n}`}
                          className="w-full text-left px-2.5 py-1.5 text-sm rounded-md border border-zinc-200 dark:border-zinc-700 hover:border-zinc-300 dark:hover:border-zinc-600 text-zinc-900 dark:text-zinc-100 transition-colors cursor-text"
                        >
                          {part.n ? <PartNameText name={part.n} /> : <span className="text-zinc-400">Nome da peça</span>}
                        </button>
                      )}
                    </td>
                    <td className="py-2.5 px-4 min-w-[150px]">
                      <input
                        type="text"
                        value={part.c}
                        onChange={(e) => onUpdatePart(id, 'c', e.target.value)}
                        aria-label={`Código da peça ${part.n}`}
                        className="w-full px-2.5 py-1.5 text-xs font-mono rounded-md border border-zinc-200 dark:border-zinc-700 bg-transparent focus:bg-white dark:focus:bg-zinc-900 text-zinc-700 dark:text-zinc-300 focus:outline-none focus:border-[#E31E24]"
                      />
                    </td>
                    <td className="py-2.5 px-4 w-36">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={part.p}
                        onChange={(e) =>
                          onUpdatePart(id, 'p', Math.max(0, parseFloat(e.target.value) || 0))
                        }
                        aria-label={`Valor unitário de ${part.n}`}
                        className="w-full px-2.5 py-1.5 text-sm font-mono tabular-nums text-right rounded-md border border-zinc-200 dark:border-zinc-700 bg-transparent focus:bg-white dark:focus:bg-zinc-900 text-zinc-900 dark:text-zinc-100 focus:outline-none focus:border-[#E31E24]"
                      />
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-xs text-zinc-500 dark:text-zinc-400">
                      {uses}
                    </td>
                    <td className="py-2.5 px-4 text-right whitespace-nowrap">
                      {!confirming ? (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(id)}
                          aria-label={`Excluir ${part.n}`}
                          className="p-1.5 text-zinc-400 hover:text-[#E31E24] transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      ) : (
                        <div className="inline-flex items-center gap-1.5 text-xs">
                          <button
                            type="button"
                            onClick={() => {
                              onDeletePart(id);
                              setConfirmDeleteId(null);
                            }}
                            className="px-2 py-1 rounded bg-[#E31E24] text-white font-semibold cursor-pointer"
                          >
                            Excluir
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2 py-1 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 cursor-pointer"
                          >
                            Cancelar
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}

              {partIds.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-xs text-zinc-500">
                    Nenhuma peça encontrada.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
