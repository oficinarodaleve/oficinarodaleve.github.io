import React from 'react';
import type { ActiveTab } from '../types';
import { buildWhatsAppUrl } from '../utils/maintenance';

interface HeaderProps {
  isAdmin: boolean;
  activeTab: ActiveTab;
  onNavigateTab: (tab: ActiveTab) => void;
  onJumpToLocations: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  isAdmin,
  activeTab,
  onNavigateTab,
  onJumpToLocations,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#121215]/95 backdrop-blur-sm border-b border-zinc-200 dark:border-zinc-800">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            onNavigateTab('1');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="inline-flex items-center shrink-0 rounded-md dark:bg-white dark:px-2.5 dark:py-1 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E31E24]"
          aria-label="Rodaleve – Início"
        >
          <img
            src="/rodaleve-logo.png"
            alt="Rodaleve – Especialista em Consórcio"
            className="h-8 sm:h-9 w-auto object-contain"
            referrerPolicy="no-referrer"
          />
        </a>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-zinc-600 dark:text-zinc-300">
          <button
            type="button"
            onClick={() => {
              if (activeTab === 'faq' || activeTab === 'precos') {
                onNavigateTab('1');
              }
              document.getElementById('catalogo')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeTab !== 'faq' && activeTab !== 'precos'
                ? 'border-[#E31E24] text-zinc-900 dark:text-white font-semibold'
                : 'border-transparent hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            Revisões
          </button>
          <button
            type="button"
            onClick={() => {
              onNavigateTab('faq');
              document.getElementById('catalogo')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'faq'
                ? 'border-[#E31E24] text-zinc-900 dark:text-white font-semibold'
                : 'border-transparent hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            Dúvidas Frequentes
          </button>
          {isAdmin && (
            <button
              type="button"
              onClick={() => {
                onNavigateTab('precos');
                document.getElementById('catalogo')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'precos'
                  ? 'border-[#E31E24] text-zinc-900 dark:text-white font-semibold'
                  : 'border-transparent hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              Peças e Preços
            </button>
          )}
          <button
            type="button"
            onClick={onJumpToLocations}
            className="whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:text-zinc-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            Unidades
          </button>
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="flex items-center shrink-0">
          <a
            href={buildWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-[#E31E24] hover:bg-[#B91419] rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E31E24]"
          >
            Agendar revisão
          </a>
        </div>
      </div>
    </header>
  );
};
