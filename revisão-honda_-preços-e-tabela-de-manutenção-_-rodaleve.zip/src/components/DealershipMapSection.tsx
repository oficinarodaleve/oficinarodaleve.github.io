/// <reference types="google.maps" />
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AdvancedMarker,
  APILoadingStatus,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  Bike,
  Car,
  ExternalLink,
  Loader2,
  LocateFixed,
  MapPin,
  Navigation,
  Phone,
  Route as RouteIcon,
  Star,
  X,
} from 'lucide-react';

const ATTRIBUTION_IDS = ['gmp_mcp_codeassist_v1_aistudio'];

export interface DealershipBranch {
  id: 'vca' | 'gbi';
  title: string;
  cnpj: string;
  addressLines: string[];
  phoneDisplay: string;
  phoneHref: string;
  textQuery: string;
  fallbackMapsUrl: string;
}

export const BRANCHES: DealershipBranch[] = [
  {
    id: 'vca',
    title: 'Rodaleve Vitória da Conquista',
    cnpj: '13.456.165/0001-14',
    addressLines: ['Av. Presidente Dutra, 2879', 'Vitória da Conquista – BA, 45015-660'],
    phoneDisplay: '(77) 3427-8000',
    phoneHref: 'tel:+557734278000',
    textQuery: 'Honda Rodaleve, Av. Presidente Dutra, 2879, Vitória da Conquista - BA',
    fallbackMapsUrl:
      'https://www.google.com/maps/search/?api=1&query=Honda%20Rodaleve%2C%20Av.%20Presidente%20Dutra%2C%202879%2C%20Vit%C3%B3ria%20da%20Conquista%20-%20BA',
  },
  {
    id: 'gbi',
    title: 'Rodaleve Guanambi',
    cnpj: '02.721.782/0001-83',
    addressLines: ['Av. Santos Dumont, 1427 – Lot Municipal', 'Guanambi – BA, 46430-000'],
    phoneDisplay: '(77) 3451-8000',
    phoneHref: 'tel:+557734518000',
    textQuery: 'Rodaleve Guanambi, Av. Santos Dumont, 1427, Guanambi - BA',
    fallbackMapsUrl:
      'https://www.google.com/maps/search/?api=1&query=Rodaleve%20Guanambi%2C%20Av.%20Santos%20Dumont%2C%201427%2C%20Guanambi%20-%20BA',
  },
];

interface ResolvedPlaceData {
  placeId: string;
  displayName?: string | null;
  formattedAddress?: string | null;
  location: google.maps.LatLngLiteral;
  googleMapsURI?: string | null;
  rating?: number | null;
  userRatingCount?: number | null;
}

function isQuotaError(err: unknown): boolean {
  const text = err instanceof Error ? err.message : String(err);
  return (
    text.includes('RESOURCE_EXHAUSTED') ||
    text.includes('OVER_QUERY_LIMIT') ||
    text.includes('QuotaExceededError') ||
    text.includes('429')
  );
}

interface BranchMarkerProps {
  branch: DealershipBranch;
  resolved: ResolvedPlaceData;
  isSelected: boolean;
  isInfoOpen: boolean;
  onSelect: () => void;
  onCloseInfo: () => void;
}

const BranchMarker: React.FC<BranchMarkerProps> = ({
  branch,
  resolved,
  isSelected,
  isInfoOpen,
  onSelect,
  onCloseInfo,
}) => {
  const [markerRef, marker] = useAdvancedMarkerRef();

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={resolved.location}
        title={resolved.displayName || branch.title}
        zIndex={isSelected ? 100 : 10}
        onClick={onSelect}
      >
        <Pin
          background={isSelected ? '#E31E24' : '#18181B'}
          borderColor={isSelected ? '#991B1B' : '#3F3F46'}
          glyphColor="#FFFFFF"
          scale={isSelected ? 1.2 : 1.0}
        />
      </AdvancedMarker>

      {isInfoOpen && marker && (
        <InfoWindow anchor={marker} onCloseClick={onCloseInfo} maxWidth={280}>
          <div className="p-1 text-zinc-900 space-y-1.5 font-sans">
            <h4 className="font-bold text-sm leading-tight">
              {resolved.displayName || branch.title}
            </h4>
            <p className="text-xs text-zinc-600 leading-snug">
              {resolved.formattedAddress || branch.addressLines.join(', ')}
            </p>
            {typeof resolved.rating === 'number' && (
              <div className="flex items-center gap-1 text-xs text-zinc-700">
                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span className="font-semibold tabular-nums">{resolved.rating.toFixed(1)}</span>
                {typeof resolved.userRatingCount === 'number' && (
                  <span className="text-zinc-500">({resolved.userRatingCount})</span>
                )}
              </div>
            )}
            <div className="pt-1 flex items-center gap-3 text-xs">
              <a
                href={branch.phoneHref}
                className="font-medium text-zinc-700 hover:text-[#E31E24]"
              >
                {branch.phoneDisplay}
              </a>
              <a
                href={resolved.googleMapsURI || branch.fallbackMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-semibold text-[#E31E24] hover:underline inline-flex items-center gap-1"
              >
                Abrir no Maps
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </InfoWindow>
      )}
    </>
  );
};

interface InteractiveMapInnerProps {
  hasApiKey: boolean;
}

const InteractiveMapInner: React.FC<InteractiveMapInnerProps> = ({ hasApiKey }) => {
  const map = useMap();
  const placesLib = useMapsLibrary('places');
  const routesLib = useMapsLibrary('routes');
  const apiStatus = useApiLoadingStatus();

  const [resolvedByBranch, setResolvedByBranch] = useState<Record<string, ResolvedPlaceData>>({});
  const [placesLoading, setPlacesLoading] = useState<boolean>(hasApiKey);
  const [selectedBranchId, setSelectedBranchId] = useState<'vca' | 'gbi'>('vca');
  const [openInfoId, setOpenInfoId] = useState<'vca' | 'gbi' | null>('vca');

  // Route planner state
  const [originQuery, setOriginQuery] = useState('');
  const [suggestions, setSuggestions] = useState<google.maps.places.AutocompleteSuggestion[]>([]);
  const [originPoint, setOriginPoint] = useState<{
    label: string;
    location: google.maps.LatLngLiteral;
  } | null>(null);
  const [travelMode, setTravelMode] = useState<'TWO_WHEELER' | 'DRIVING'>('TWO_WHEELER');
  const [routeSummary, setRouteSummary] = useState<{
    distanceText: string;
    durationText: string;
    usedModeLabel: string;
  } | null>(null);
  const [routeLoading, setRouteLoading] = useState(false);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);

  const sessionTokenRef = useRef<google.maps.places.AutocompleteSessionToken | null>(null);
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  // Resolve dealership locations via Places API (New) Place.searchByText
  useEffect(() => {
    if (!placesLib || !hasApiKey) return;
    let cancelled = false;
    setPlacesLoading(true);

    const resolveAll = async () => {
      const next: Record<string, ResolvedPlaceData> = {};
      for (const branch of BRANCHES) {
        try {
          const { places } = await placesLib.Place.searchByText({
            textQuery: branch.textQuery,
            fields: [
              'id',
              'displayName',
              'formattedAddress',
              'location',
              'googleMapsURI',
              'rating',
              'userRatingCount',
            ],
            language: 'pt-BR',
            region: 'BR',
            maxResultCount: 1,
            internalUsageAttributionIds: ATTRIBUTION_IDS,
          });
          const place = places?.[0];
          if (place?.location) {
            next[branch.id] = {
              placeId: place.id,
              displayName: place.displayName,
              formattedAddress: place.formattedAddress,
              location: { lat: place.location.lat(), lng: place.location.lng() },
              googleMapsURI: place.googleMapsURI,
              rating: place.rating,
              userRatingCount: place.userRatingCount,
            };
          }
        } catch (err) {
          if (isQuotaError(err)) {
            window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
          }
        }
      }
      if (!cancelled) {
        setResolvedByBranch(next);
        setPlacesLoading(false);
      }
    };

    void resolveAll();
    return () => {
      cancelled = true;
    };
  }, [placesLib, hasApiKey]);

  // Fit bounds to show both dealerships once resolved
  const fitAllBranches = useCallback(() => {
    if (!map) return;
    const resolvedList = Object.values(resolvedByBranch);
    if (resolvedList.length === 0) return;
    if (resolvedList.length === 1) {
      map.panTo(resolvedList[0].location);
      map.setZoom(15);
      return;
    }
    const bounds = new google.maps.LatLngBounds();
    resolvedList.forEach((p) => bounds.extend(p.location));
    map.fitBounds(bounds, { top: 48, right: 48, bottom: 48, left: 48 });
  }, [map, resolvedByBranch]);

  useEffect(() => {
    if (Object.keys(resolvedByBranch).length > 0 && !originPoint) {
      fitAllBranches();
    }
  }, [resolvedByBranch, fitAllBranches, originPoint]);

  const handleFocusBranch = useCallback(
    (branchId: 'vca' | 'gbi') => {
      setSelectedBranchId(branchId);
      setOpenInfoId(branchId);
      const target = resolvedByBranch[branchId];
      if (map && target) {
        map.panTo(target.location);
        map.setZoom(15);
      }
    },
    [map, resolvedByBranch]
  );

  // Autocomplete Suggestions for origin input
  useEffect(() => {
    if (!placesLib || !originQuery.trim() || originPoint?.label === originQuery) {
      setSuggestions([]);
      return;
    }

    const timer = window.setTimeout(async () => {
      try {
        if (!sessionTokenRef.current) {
          sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
        }
        const res = await placesLib.AutocompleteSuggestion.fetchAutocompleteSuggestions({
          input: originQuery.trim(),
          sessionToken: sessionTokenRef.current,
          includedRegionCodes: ['br'],
          language: 'pt-BR',
          region: 'BR',
          internalUsageAttributionIds: ATTRIBUTION_IDS,
        });
        setSuggestions(res.suggestions || []);
      } catch (err) {
        if (isQuotaError(err)) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        setSuggestions([]);
      }
    }, 220);

    return () => window.clearTimeout(timer);
  }, [placesLib, originQuery, originPoint]);

  const clearRoute = useCallback(() => {
    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];
    setRouteSummary(null);
    setRouteError(null);
    setOriginPoint(null);
    setOriginQuery('');
    setSuggestions([]);
    fitAllBranches();
  }, [fitAllBranches]);

  const handleSelectSuggestion = async (suggestion: google.maps.places.AutocompleteSuggestion) => {
    if (!placesLib || !suggestion.placePrediction) return;
    try {
      const place = suggestion.placePrediction.toPlace();
      await place.fetchFields({ fields: ['location', 'formattedAddress', 'displayName'] });
      sessionTokenRef.current = null;
      setSuggestions([]);
      if (place.location) {
        const label =
          place.formattedAddress || place.displayName || suggestion.placePrediction.text.text;
        setOriginQuery(label);
        setOriginPoint({
          label,
          location: { lat: place.location.lat(), lng: place.location.lng() },
        });
      }
    } catch (err) {
      if (isQuotaError(err)) {
        window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
      }
      setRouteError('Não foi possível obter as coordenadas deste endereço.');
    }
  };

  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      setRouteError('Geolocalização não suportada neste navegador.');
      return;
    }
    setGeoLoading(true);
    setRouteError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeoLoading(false);
        const label = 'Minha localização atual';
        setOriginQuery(label);
        setSuggestions([]);
        setOriginPoint({
          label,
          location: { lat: pos.coords.latitude, lng: pos.coords.longitude },
        });
      },
      () => {
        setGeoLoading(false);
        setRouteError('Permissão de localização negada. Digite seu endereço ou cidade.');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // Compute route when originPoint + destination + routesLib are ready
  useEffect(() => {
    const dest = resolvedByBranch[selectedBranchId];
    if (!originPoint || !dest || !routesLib || !map) return;

    let cancelled = false;
    const runRoute = async () => {
      setRouteLoading(true);
      setRouteError(null);
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];

      const tryCompute = async (mode: 'TWO_WHEELER' | 'DRIVING') => {
        return routesLib.Route.computeRoutes({
          origin: originPoint.location,
          destination: dest.location,
          travelMode: mode,
          fields: ['durationMillis', 'distanceMeters', 'localizedValues', 'path', 'viewport'],
          internalUsageAttributionIds: ATTRIBUTION_IDS,
        });
      };

      try {
        let modeUsed: 'TWO_WHEELER' | 'DRIVING' = travelMode;
        let response = await tryCompute(travelMode).catch(async (err) => {
          if (travelMode === 'TWO_WHEELER' && !isQuotaError(err)) {
            modeUsed = 'DRIVING';
            return tryCompute('DRIVING');
          }
          throw err;
        });

        let route = response?.routes?.[0];
        if (!route && travelMode === 'TWO_WHEELER') {
          modeUsed = 'DRIVING';
          response = await tryCompute('DRIVING');
          route = response?.routes?.[0];
        }

        if (cancelled) return;

        if (!route) {
          setRouteSummary(null);
          setRouteError('Nenhuma rota rodoviária encontrada entre os pontos.');
          return;
        }

        const newPolylines = route.createPolylines({
          polylineOptions: {
            strokeColor: '#E31E24',
            strokeOpacity: 0.9,
            strokeWeight: 5,
          },
        });
        newPolylines.forEach((p) => p.setMap(map));
        polylinesRef.current = newPolylines;

        if (route.viewport) {
          map.fitBounds(route.viewport, { top: 48, right: 48, bottom: 48, left: 48 });
        }

        const distanceText =
          route.localizedValues?.distance ||
          (typeof route.distanceMeters === 'number'
            ? `${(route.distanceMeters / 1000).toFixed(1)} km`
            : '—');
        const durationText =
          route.localizedValues?.duration ||
          (typeof route.durationMillis === 'number'
            ? `${Math.round(route.durationMillis / 60000)} min`
            : '—');

        setRouteSummary({
          distanceText,
          durationText,
          usedModeLabel: modeUsed === 'TWO_WHEELER' ? 'Moto' : 'Carro',
        });
      } catch (err) {
        if (cancelled) return;
        if (isQuotaError(err)) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        setRouteSummary(null);
        setRouteError('Não foi possível calcular a rota agora. Tente abrir diretamente no Google Maps.');
      } finally {
        if (!cancelled) {
          setRouteLoading(false);
        }
      }
    };

    void runRoute();
    return () => {
      cancelled = true;
    };
  }, [originPoint, selectedBranchId, travelMode, resolvedByBranch, routesLib, map]);

  // Cleanup polylines on unmount
  useEffect(() => {
    return () => {
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, []);

  const mapFailed =
    !hasApiKey ||
    apiStatus === APILoadingStatus.FAILED ||
    apiStatus === APILoadingStatus.AUTH_FAILURE;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">
            Unidades Rodaleve e Como Chegar
          </h2>
          <p className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">
            Localize nossas concessionárias autorizadas em Vitória da Conquista e Guanambi ou trace a melhor rota de moto.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {BRANCHES.map((branch) => {
            const active = selectedBranchId === branch.id;
            return (
              <button
                key={branch.id}
                type="button"
                onClick={() => handleFocusBranch(branch.id)}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#E31E24] text-white'
                    : 'bg-white dark:bg-[#16161A] text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700'
                }`}
              >
                {branch.id === 'vca' ? 'Vitória da Conquista' : 'Guanambi'}
              </button>
            );
          })}
          <button
            type="button"
            onClick={fitAllBranches}
            className="px-3.5 py-2 rounded-lg text-xs font-medium bg-zinc-100 dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-800 hover:text-zinc-900 dark:hover:text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
          >
            Ver ambas
          </button>
        </div>
      </div>

      {/* Main Split: Left Route & Unit Cards | Right Interactive Map */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left column: Units + Route Planner */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          {/* Route Planner Card */}
          <div className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                <RouteIcon className="w-4 h-4 text-[#E31E24]" />
                <span>Traçar rota até {selectedBranchId === 'vca' ? 'Vitória da Conquista' : 'Guanambi'}</span>
              </div>
              <div className="flex items-center gap-1 p-0.5 bg-zinc-100 dark:bg-zinc-900 rounded-md border border-zinc-200 dark:border-zinc-800">
                <button
                  type="button"
                  onClick={() => setTravelMode('TWO_WHEELER')}
                  title="Rota para moto"
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium cursor-pointer ${
                    travelMode === 'TWO_WHEELER'
                      ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-xs'
                      : 'text-zinc-500'
                  }`}
                >
                  <Bike className="w-3.5 h-3.5" />
                  <span>Moto</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTravelMode('DRIVING')}
                  title="Rota para carro"
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium cursor-pointer ${
                    travelMode === 'DRIVING'
                      ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-xs'
                      : 'text-zinc-500'
                  }`}
                >
                  <Car className="w-3.5 h-3.5" />
                  <span>Carro</span>
                </button>
              </div>
            </div>

            <div className="relative">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={originQuery}
                  onChange={(e) => {
                    setOriginQuery(e.target.value);
                    if (originPoint && e.target.value !== originPoint.label) {
                      setOriginPoint(null);
                    }
                  }}
                  placeholder="Digite seu endereço ou cidade de partida…"
                  aria-label="Endereço de partida"
                  disabled={mapFailed}
                  className="flex-1 min-w-0 px-3 py-2 text-sm rounded-lg border border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 focus:outline-none focus:border-[#E31E24] disabled:opacity-50"
                />
                <button
                  type="button"
                  onClick={handleUseCurrentLocation}
                  disabled={geoLoading || mapFailed}
                  title="Usar minha localização atual"
                  aria-label="Usar minha localização atual"
                  className="px-3 py-2 rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-200 hover:border-[#E31E24] hover:text-[#E31E24] transition-colors shrink-0 cursor-pointer disabled:opacity-50"
                >
                  {geoLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <LocateFixed className="w-4 h-4" />
                  )}
                </button>
              </div>

              {suggestions.length > 0 && (
                <ul className="absolute z-30 left-0 right-0 mt-1 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg shadow-lg max-h-56 overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800">
                  {suggestions.map((s, idx) => (
                    <li key={s.placePrediction?.placeId || idx}>
                      <button
                        type="button"
                        onClick={() => void handleSelectSuggestion(s)}
                        className="w-full text-left px-3 py-2 text-xs text-zinc-700 dark:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-zinc-800 cursor-pointer"
                      >
                        {s.placePrediction?.text.text}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {routeLoading && (
              <div className="flex items-center gap-2 text-xs text-zinc-500">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E31E24]" />
                <span>Calculando melhor rota…</span>
              </div>
            )}

            {routeSummary && (
              <div className="flex items-center justify-between gap-3 px-3 py-2 rounded-lg bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs">
                <div className="flex items-center gap-2 text-zinc-800 dark:text-zinc-200">
                  <Navigation className="w-3.5 h-3.5 text-[#E31E24] shrink-0" />
                  <span className="font-semibold tabular-nums">{routeSummary.distanceText}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-semibold tabular-nums">{routeSummary.durationText}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-zinc-500">{routeSummary.usedModeLabel}</span>
                </div>
                <button
                  type="button"
                  onClick={clearRoute}
                  className="text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 cursor-pointer"
                  aria-label="Limpar rota"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {routeError && (
              <p className="text-xs text-red-600 dark:text-red-400">{routeError}</p>
            )}
          </div>

          {/* Two Dealership Unit Cards */}
          {BRANCHES.map((branch) => {
            const resolved = resolvedByBranch[branch.id];
            const isSelected = selectedBranchId === branch.id;

            return (
              <div
                key={branch.id}
                className={`bg-white dark:bg-[#16161A] border rounded-xl p-4 transition-colors ${
                  isSelected
                    ? 'border-[#E31E24]'
                    : 'border-zinc-200 dark:border-zinc-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-bold text-zinc-900 dark:text-white">
                      {branch.title}
                    </h3>
                    <p className="text-xs font-mono text-zinc-500 dark:text-zinc-400 mt-0.5">
                      CNPJ {branch.cnpj}
                    </p>
                  </div>
                  {typeof resolved?.rating === 'number' && (
                    <div className="inline-flex items-center gap-1 text-xs font-semibold text-zinc-700 dark:text-zinc-200 shrink-0">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      <span className="tabular-nums">{resolved.rating.toFixed(1)}</span>
                    </div>
                  )}
                </div>

                <div className="mt-2.5 text-sm text-zinc-600 dark:text-zinc-300 space-y-0.5">
                  {branch.addressLines.map((line) => (
                    <p key={line}>{line}</p>
                  ))}
                </div>

                <div className="mt-3 pt-3 border-t border-zinc-100 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <a
                    href={branch.phoneHref}
                    className="inline-flex items-center gap-1.5 font-medium text-zinc-700 dark:text-zinc-300 hover:text-[#E31E24]"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{branch.phoneDisplay}</span>
                  </a>

                  <div className="flex items-center gap-3">
                    {resolved && (
                      <button
                        type="button"
                        onClick={() => handleFocusBranch(branch.id)}
                        className="inline-flex items-center gap-1 font-semibold text-zinc-700 dark:text-zinc-200 hover:text-[#E31E24] cursor-pointer"
                      >
                        <MapPin className="w-3.5 h-3.5" />
                        <span>Focar no mapa</span>
                      </button>
                    )}
                    <a
                      href={resolved?.googleMapsURI || branch.fallbackMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 font-semibold text-[#E31E24] hover:underline"
                    >
                      <span>Abrir no Maps</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right column: Interactive Google Map */}
        <div className="lg:col-span-7">
          <div className="h-[400px] lg:h-full lg:min-h-[460px] w-full rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-800 bg-zinc-100 dark:bg-zinc-900 relative">
            {mapFailed ? (
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center space-y-3">
                <MapPin className="w-8 h-8 text-zinc-400" />
                <div className="space-y-1 max-w-sm">
                  <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
                    Mapa interativo indisponível no momento
                  </p>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    Você pode abrir a localização das unidades diretamente no Google Maps usando os links ao lado.
                  </p>
                </div>
              </div>
            ) : (
              <>
                <GoogleMap
                  mapId="DEMO_MAP_ID"
                  defaultCenter={{ lat: -14.2, lng: -41.8 }}
                  defaultZoom={7}
                  gestureHandling="greedy"
                  internalUsageAttributionIds={ATTRIBUTION_IDS}
                  style={{ width: '100%', height: '100%' }}
                  onClick={() => setOpenInfoId(null)}
                >
                  {originPoint && (
                    <AdvancedMarker
                      position={originPoint.location}
                      title={originPoint.label}
                      zIndex={50}
                    >
                      <Pin background="#2563EB" borderColor="#1D4ED8" glyphColor="#FFFFFF" />
                    </AdvancedMarker>
                  )}

                  {BRANCHES.map((branch) => {
                    const resolved = resolvedByBranch[branch.id];
                    if (!resolved) return null;
                    return (
                      <BranchMarker
                        key={branch.id}
                        branch={branch}
                        resolved={resolved}
                        isSelected={selectedBranchId === branch.id}
                        isInfoOpen={openInfoId === branch.id}
                        onSelect={() => {
                          setSelectedBranchId(branch.id);
                          setOpenInfoId(branch.id);
                        }}
                        onCloseInfo={() => setOpenInfoId(null)}
                      />
                    );
                  })}
                </GoogleMap>

                {placesLoading && (
                  <div className="absolute top-3 left-3 bg-white/95 dark:bg-zinc-900/95 border border-zinc-200 dark:border-zinc-700 rounded-lg px-3 py-1.5 text-xs font-medium text-zinc-700 dark:text-zinc-200 flex items-center gap-2 shadow-sm">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E31E24]" />
                    <span>Localizando concessionárias…</span>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export const DealershipMapSection: React.FC<{ hasApiKey: boolean }> = ({ hasApiKey }) => {
  if (!hasApiKey) {
    return (
      <section id="unidades" className="py-10 border-t border-zinc-200 dark:border-zinc-800 space-y-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">
            Unidades Rodaleve
          </h2>
          <p className="text-sm text-zinc-600 dark:text-zinc-400 mt-1">
            Visite nossas concessionárias autorizadas em Vitória da Conquista e Guanambi.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {BRANCHES.map((branch) => (
            <div
              key={branch.id}
              className="bg-white dark:bg-[#16161A] border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 space-y-2.5"
            >
              <h3 className="text-base font-bold text-zinc-900 dark:text-white">{branch.title}</h3>
              <p className="text-xs font-mono text-zinc-500 dark:text-zinc-400">CNPJ {branch.cnpj}</p>
              <div className="text-sm text-zinc-600 dark:text-zinc-300 space-y-0.5">
                {branch.addressLines.map((line) => (
                  <p key={line}>{line}</p>
                ))}
              </div>
              <div className="pt-2 flex items-center justify-between text-xs border-t border-zinc-100 dark:border-zinc-800">
                <a
                  href={branch.phoneHref}
                  className="inline-flex items-center gap-1.5 font-medium text-zinc-700 dark:text-zinc-300 hover:text-[#E31E24]"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{branch.phoneDisplay}</span>
                </a>
                <a
                  href={branch.fallbackMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-semibold text-[#E31E24] hover:underline"
                >
                  <span>Abrir no Maps</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section id="unidades" className="py-10 border-t border-zinc-200 dark:border-zinc-800">
      <InteractiveMapInner hasApiKey={hasApiKey} />
    </section>
  );
};
