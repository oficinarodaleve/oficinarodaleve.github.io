import React from 'react';
import { CATEGORY_LABELS, getModelCategory } from '../utils/maintenance';

interface MotoPlaceholderProps {
  modelName: string;
}

export const MotoPlaceholder: React.FC<MotoPlaceholderProps> = ({ modelName }) => {
  const category = getModelCategory(modelName);
  const label = CATEGORY_LABELS[category];

  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-4 py-3 text-zinc-400 dark:text-zinc-500 select-none">
      {category === 'cub_scooter' && (
        <svg
          viewBox="0 0 180 96"
          className="w-36 h-20 text-zinc-300 dark:text-zinc-600"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <circle cx="40" cy="68" r="18" />
          <circle cx="40" cy="68" r="6" />
          <circle cx="138" cy="68" r="17" />
          <circle cx="138" cy="68" r="5.5" />
          <path d="M58 68h36l14-24h18" />
          <path d="M40 68l16-30h32l12 12" />
          <path d="M126 44l-10-20h-12" />
          <path d="M52 38c14-4 28-4 40 2" />
          <path d="M116 24l10-6" />
        </svg>
      )}
      {category === 'street_trail' && (
        <svg
          viewBox="0 0 180 96"
          className="w-36 h-20 text-zinc-300 dark:text-zinc-600"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <circle cx="38" cy="68" r="19" />
          <circle cx="38" cy="68" r="6" />
          <circle cx="142" cy="68" r="19" />
          <circle cx="142" cy="68" r="6" />
          <path d="M38 68l28-30h34l20 14" />
          <path d="M142 68l-22-46h-12" />
          <path d="M62 38l22-8 24 6" />
          <path d="M66 38l-14 20h44l10-18" />
          <path d="M120 22l12-4" />
        </svg>
      )}
      {category === 'alta' && (
        <svg
          viewBox="0 0 180 96"
          className="w-36 h-20 text-zinc-300 dark:text-zinc-600"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <circle cx="38" cy="67" r="20" />
          <circle cx="38" cy="67" r="6.5" />
          <circle cx="142" cy="67" r="20" />
          <circle cx="142" cy="67" r="6.5" />
          <path d="M38 67l28-34h36l22 18" />
          <path d="M142 67l-20-48h-16" />
          <path d="M58 33l26-10 34 8" />
          <path d="M122 19l14-6 6 8" />
          <path d="M66 35l-12 22h48l12-20" />
          <path d="M24 44l16-8" />
        </svg>
      )}
      <span className="mt-1.5 text-[11px] font-medium tracking-wide uppercase text-zinc-400 dark:text-zinc-500">
        {label}
      </span>
    </div>
  );
};
