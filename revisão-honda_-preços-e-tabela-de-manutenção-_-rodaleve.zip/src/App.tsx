import React, { useCallback, useEffect, useState } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import type { ActiveTab, MaintenanceData } from './types';
import {
  downloadFile,
  exportStandaloneHtml,
  getAllCategories,
  getCustomModelPhoto,
  getSeedData,
  loadInitialData,
  normalizeDataModelNames,
  persistData,
  resizeImageFile,
  slugifyCategoryId,
  STORAGE_KEY,
} from './utils/maintenance';
import { Header } from './components/Header';
import { AdminToolbar } from './components/AdminToolbar';
import { RevisionCatalog } from './components/RevisionCatalog';
import { PartsManager } from './components/PartsManager';
import { FaqSection } from './components/FaqSection';
import { DealershipMapSection } from './components/DealershipMapSection';
import { FooterSection } from './components/FooterSection';
import { WhatsAppFloat } from './components/WhatsAppFloat';

const MAPS_API_KEY = (import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined) || '';

export default function App() {
  const [data, setData] = useState<MaintenanceData>(() => loadInitialData());
  const [activeTab, setActiveTab] = useState<ActiveTab>('1');
  const [isAdmin, setIsAdmin] = useState<boolean>(
    () => window.location.hash === '#admin' || window.location.protocol === 'file:'
  );
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(
    null
  );
  const [quotaExceeded, setQuotaExceeded] = useState<boolean>(false);

  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('rodaleve_theme');
      if (saved === 'dark') return true;
      if (saved === 'light') return false;
    } catch {
      // Ignore storage error
    }
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
  });

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
    try {
      localStorage.setItem('rodaleve_theme', isDark ? 'dark' : 'light');
    } catch {
      // Ignore storage error
    }
  }, [isDark]);

  useEffect(() => {
    const onHashChange = () => {
      if (window.location.hash === '#admin') {
        setIsAdmin(true);
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  useEffect(() => {
    const onQuotaExceeded = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  const commitData = useCallback((updater: (prev: MaintenanceData) => MaintenanceData) => {
    setData((prev) => {
      const next = updater(prev);
      const res = persistData(next);
      if (!res.ok && res.error) {
        setStatusMessage({ type: 'err', text: res.error });
      }
      return res.data;
    });
  }, []);

  const REVISION_KEYS = ['1', '2', '3', '4', '5', '6', '7'] as const;
  const hiddenRevs = data.hiddenRevs || [];
  const firstVisibleRevision =
    (REVISION_KEYS.find((k) => !hiddenRevs.includes(k)) as ActiveTab | undefined) || '1';

  useEffect(() => {
    if (
      !isAdmin &&
      !isEditing &&
      REVISION_KEYS.includes(activeTab as (typeof REVISION_KEYS)[number]) &&
      hiddenRevs.includes(activeTab)
    ) {
      setActiveTab(firstVisibleRevision);
    }
  }, [isAdmin, isEditing, activeTab, hiddenRevs, firstVisibleRevision]);

  const handleToggleAdmin = useCallback(() => {
    setIsAdmin((prev) => {
      const next = !prev;
      if (!next) {
        setIsEditing(false);
        if (activeTab === 'precos' || hiddenRevs.includes(activeTab)) {
          setActiveTab(firstVisibleRevision);
        }
        if (window.location.hash === '#admin') {
          history.replaceState(null, '', window.location.pathname + window.location.search);
        }
      }
      return next;
    });
  }, [activeTab, hiddenRevs, firstVisibleRevision]);

  // Model & revision mutations
  const handleUpdateModelName = useCallback(
    (revKey: string, modelIndex: number, newName: string) => {
      const formattedName = newName.toLocaleUpperCase('pt-BR');
      commitData((prev) => {
        const list = [...(prev.revs[revKey] || [])];
        const oldName = list[modelIndex]?.m;
        list[modelIndex] = { ...list[modelIndex], m: formattedName };
        const photos = { ...prev.photos };
        const oldPhoto = oldName ? getCustomModelPhoto(photos, oldName) : undefined;
        if (oldPhoto && !getCustomModelPhoto(photos, formattedName)) {
          photos[formattedName.trim()] = oldPhoto;
        }
        return { ...prev, revs: { ...prev.revs, [revKey]: list }, photos };
      });
    },
    [commitData]
  );

  const handleUploadPhoto = useCallback(
    async (modelName: string, file: File) => {
      try {
        const dataUrl = await resizeImageFile(file);
        const normalizedKey = modelName.trim().toLocaleUpperCase('pt-BR');
        commitData((prev) => ({
          ...prev,
          photos: { ...prev.photos, [normalizedKey]: dataUrl },
        }));
        setStatusMessage({ type: 'ok', text: `Foto atualizada para ${normalizedKey}.` });
      } catch {
        setStatusMessage({ type: 'err', text: 'Não foi possível processar a imagem selecionada.' });
      }
    },
    [commitData]
  );

  const handleRemovePhoto = useCallback(
    (modelName: string) => {
      commitData((prev) => {
        const photos = { ...prev.photos };
        const targetLower = modelName.trim().toLowerCase();
        for (const key of Object.keys(photos)) {
          if (key.trim().toLowerCase() === targetLower) {
            delete photos[key];
          }
        }
        return { ...prev, photos };
      });
    },
    [commitData]
  );

  const handleUpdateItemQty = useCallback(
    (revKey: string, modelIndex: number, itemIndex: number, qty: number) => {
      commitData((prev) => {
        const list = [...(prev.revs[revKey] || [])];
        const items = [...list[modelIndex].i];
        items[itemIndex] = { ...items[itemIndex], q: qty };
        list[modelIndex] = { ...list[modelIndex], i: items };
        return { ...prev, revs: { ...prev.revs, [revKey]: list } };
      });
    },
    [commitData]
  );

  const handleUpdatePartPrice = useCallback(
    (partId: string, price: number) => {
      commitData((prev) => ({
        ...prev,
        parts: {
          ...prev.parts,
          [partId]: { ...prev.parts[partId], p: price },
        },
      }));
    },
    [commitData]
  );

  const handleRemoveItem = useCallback(
    (revKey: string, modelIndex: number, itemIndex: number) => {
      commitData((prev) => {
        const list = [...(prev.revs[revKey] || [])];
        const items = list[modelIndex].i.filter((_, idx) => idx !== itemIndex);
        list[modelIndex] = { ...list[modelIndex], i: items };
        return { ...prev, revs: { ...prev.revs, [revKey]: list } };
      });
    },
    [commitData]
  );

  const handleAddItem = useCallback(
    (revKey: string, modelIndex: number, partId: string) => {
      commitData((prev) => {
        const list = [...(prev.revs[revKey] || [])];
        const items = [...list[modelIndex].i, { p: partId, q: 1 }];
        list[modelIndex] = { ...list[modelIndex], i: items };
        return { ...prev, revs: { ...prev.revs, [revKey]: list } };
      });
    },
    [commitData]
  );

  const handleDeleteModel = useCallback(
    (revKey: string, modelIndex: number) => {
      commitData((prev) => {
        const list = (prev.revs[revKey] || []).filter((_, idx) => idx !== modelIndex);
        return { ...prev, revs: { ...prev.revs, [revKey]: list } };
      });
    },
    [commitData]
  );

  const handleAddModel = useCallback(
    (revKey: string, modelName?: string, addToAllRevisions = false, categoryId?: string) => {
      const cleanName =
        (modelName || 'NOVO MODELO').trim().toLocaleUpperCase('pt-BR') || 'NOVO MODELO';
      commitData((prev) => {
        const nextRevs = { ...prev.revs };
        const newEntry = categoryId
          ? { m: cleanName, cat: categoryId, i: [] }
          : { m: cleanName, i: [] };
        if (addToAllRevisions) {
          for (const key of ['1', '2', '3', '4', '5', '6', '7']) {
            nextRevs[key] = [...(nextRevs[key] || []), { ...newEntry, i: [] }];
          }
        } else {
          nextRevs[revKey] = [...(nextRevs[revKey] || []), newEntry];
        }
        return { ...prev, revs: nextRevs };
      });
      setStatusMessage({
        type: 'ok',
        text: addToAllRevisions
          ? `Modelo "${cleanName}" adicionado da 1ª à 7ª revisão.`
          : `Modelo "${cleanName}" adicionado na ${revKey}ª revisão.`,
      });
    },
    [commitData]
  );

  const handleUpdateModelCategory = useCallback(
    (revKey: string, modelIndex: number, categoryId: string) => {
      commitData((prev) => {
        const list = [...(prev.revs[revKey] || [])];
        if (!list[modelIndex]) return prev;
        list[modelIndex] = { ...list[modelIndex], cat: categoryId };
        return { ...prev, revs: { ...prev.revs, [revKey]: list } };
      });
    },
    [commitData]
  );

  const handleToggleHiddenModel = useCallback(
    (revKey: string, modelIndex: number) => {
      const targetModel = data.revs[revKey]?.[modelIndex];
      const modelName = targetModel?.m?.trim() || 'Modelo';
      const isCurrentlyHidden = Boolean(targetModel?.hidden);
      commitData((prev) => {
        const list = [...(prev.revs[revKey] || [])];
        if (!list[modelIndex]) return prev;
        const nextHidden = !list[modelIndex].hidden;
        if (nextHidden) {
          list[modelIndex] = { ...list[modelIndex], hidden: true };
        } else {
          const { hidden: _removed, ...rest } = list[modelIndex];
          list[modelIndex] = rest;
        }
        return { ...prev, revs: { ...prev.revs, [revKey]: list } };
      });
      setStatusMessage({
        type: 'ok',
        text: isCurrentlyHidden
          ? `Modelo "${modelName}" visível novamente para os clientes.`
          : `Modelo "${modelName}" ocultado dos clientes na ${revKey}ª revisão.`,
      });
    },
    [commitData, data.revs]
  );

  const handleAddCategory = useCallback(
    (label: string): string | null => {
      const cleanLabel = label.trim();
      if (!cleanLabel) return null;
      const existingCats = getAllCategories(data);
      const existingByLabel = existingCats.find(
        (c) => c.label.trim().toLowerCase() === cleanLabel.toLowerCase()
      );
      if (existingByLabel) {
        return existingByLabel.id;
      }
      const existingIds = new Set(existingCats.map((c) => c.id));
      const baseId = slugifyCategoryId(cleanLabel);
      let id = baseId;
      let suffix = 2;
      while (existingIds.has(id)) {
        id = `${baseId}_${suffix++}`;
      }
      commitData((prev) => {
        const currentCustom = prev.categories || [];
        if (currentCustom.some((c) => c.id === id)) return prev;
        return {
          ...prev,
          categories: [...currentCustom, { id, label: cleanLabel }],
        };
      });
      setStatusMessage({
        type: 'ok',
        text: `Categoria "${cleanLabel}" criada com sucesso.`,
      });
      return id;
    },
    [commitData, data]
  );

  const handleDeleteCategory = useCallback(
    (categoryId: string) => {
      commitData((prev) => {
        const categories = (prev.categories || []).filter((c) => c.id !== categoryId);
        const hiddenCategories = (prev.hiddenCategories || []).filter((id) => id !== categoryId);
        const revs: MaintenanceData['revs'] = {};
        for (const key of Object.keys(prev.revs)) {
          revs[key] = prev.revs[key].map((model) => {
            if (model.cat === categoryId) {
              const { cat: _removed, ...rest } = model;
              return rest;
            }
            return model;
          });
        }
        return { ...prev, categories, hiddenCategories, revs };
      });
      setStatusMessage({ type: 'ok', text: 'Categoria removida.' });
    },
    [commitData]
  );

  const handleToggleHiddenCategory = useCallback(
    (categoryId: string) => {
      const catObj = getAllCategories(data).find((c) => c.id === categoryId);
      const label = catObj?.label || 'Categoria';
      const currentHidden = data.hiddenCategories || [];
      const isCurrentlyHidden = currentHidden.includes(categoryId);
      commitData((prev) => {
        const prevHidden = prev.hiddenCategories || [];
        const nextHidden = prevHidden.includes(categoryId)
          ? prevHidden.filter((id) => id !== categoryId)
          : [...prevHidden, categoryId];
        return { ...prev, hiddenCategories: nextHidden };
      });
      setStatusMessage({
        type: 'ok',
        text: isCurrentlyHidden
          ? `Categoria "${label}" visível novamente para os clientes.`
          : `Categoria "${label}" ocultada dos clientes.`,
      });
    },
    [commitData, data]
  );

  const handleRenameCategory = useCallback(
    (categoryId: string, newLabel: string) => {
      const cleanLabel = newLabel.trim();
      if (!cleanLabel) return;
      commitData((prev) => {
        const current = prev.categories || [];
        const exists = current.some((c) => c.id === categoryId);
        const categories = exists
          ? current.map((c) => (c.id === categoryId ? { ...c, label: cleanLabel } : c))
          : [...current, { id: categoryId, label: cleanLabel }];
        return { ...prev, categories };
      });
      setStatusMessage({
        type: 'ok',
        text: `Nome da categoria alterado para "${cleanLabel}".`,
      });
    },
    [commitData]
  );

  const handleReorderModels = useCallback(
    (revKey: string, fromIndex: number, toIndex: number) => {
      if (fromIndex === toIndex) return;
      commitData((prev) => {
        const list = [...(prev.revs[revKey] || [])];
        if (
          fromIndex < 0 ||
          toIndex < 0 ||
          fromIndex >= list.length ||
          toIndex >= list.length
        ) {
          return prev;
        }
        const [moved] = list.splice(fromIndex, 1);
        list.splice(toIndex, 0, moved);
        return { ...prev, revs: { ...prev.revs, [revKey]: list } };
      });
    },
    [commitData]
  );

  const handleToggleHiddenRevision = useCallback(
    (revKey: string) => {
      const currentHidden = data.hiddenRevs || [];
      const isCurrentlyHidden = currentHidden.includes(revKey);
      if (!isCurrentlyHidden) {
        const visibleAfter = REVISION_KEYS.filter(
          (k) => k !== revKey && !currentHidden.includes(k)
        );
        if (visibleAfter.length === 0) {
          setStatusMessage({
            type: 'err',
            text: 'Mantenha pelo menos uma revisão visível para os clientes.',
          });
          return;
        }
      }
      commitData((prev) => {
        const prevHidden = prev.hiddenRevs || [];
        const nextHidden = prevHidden.includes(revKey)
          ? prevHidden.filter((k) => k !== revKey)
          : [...prevHidden, revKey];
        return { ...prev, hiddenRevs: nextHidden };
      });
      setStatusMessage({
        type: 'ok',
        text: isCurrentlyHidden
          ? `${revKey}ª Revisão desbloqueada e visível para os clientes.`
          : `${revKey}ª Revisão ocultada dos clientes.`,
      });
    },
    [commitData, data.hiddenRevs]
  );

  const handleCopyRevisionToOthers = useCallback(
    (sourceRevKey: string) => {
      commitData((prev) => {
        const sourceList = prev.revs[sourceRevKey] || [];
        const nextRevs: MaintenanceData['revs'] = { ...prev.revs };
        for (const key of REVISION_KEYS) {
          if (key === sourceRevKey) continue;
          nextRevs[key] = sourceList.map((model) => ({
            ...model,
            i: model.i.map((item) => ({ ...item })),
          }));
        }
        return { ...prev, revs: nextRevs };
      });
      setStatusMessage({
        type: 'ok',
        text: `Toda a estrutura da ${sourceRevKey}ª Revisão foi copiada para as demais revisões.`,
      });
    },
    [commitData]
  );

  // Parts catalog mutations
  const handleAddPart = useCallback(() => {
    commitData((prev) => {
      const nextNum = prev.n + 1;
      return {
        ...prev,
        n: nextNum,
        parts: {
          ...prev.parts,
          [`p${nextNum}`]: { n: 'Nova peça', c: '', p: 0 },
        },
      };
    });
  }, [commitData]);

  const handleUpdatePart = useCallback(
    (partId: string, field: 'n' | 'c' | 'p', value: string | number) => {
      commitData((prev) => ({
        ...prev,
        parts: {
          ...prev.parts,
          [partId]: { ...prev.parts[partId], [field]: value },
        },
      }));
    },
    [commitData]
  );

  const handleDeletePart = useCallback(
    (partId: string) => {
      commitData((prev) => {
        const parts = { ...prev.parts };
        delete parts[partId];
        const revs: MaintenanceData['revs'] = {};
        for (const revKey of Object.keys(prev.revs)) {
          revs[revKey] = prev.revs[revKey].map((model) => ({
            ...model,
            i: model.i.filter((item) => item.p !== partId),
          }));
        }
        return { ...prev, parts, revs };
      });
    },
    [commitData]
  );

  // FAQ mutations
  const handleAddFaq = useCallback(
    (q: string, a: string) => {
      const trimmedQ = q.trim();
      const trimmedA = a.trim();
      if (!trimmedQ || !trimmedA) return;
      commitData((prev) => ({
        ...prev,
        faq: [...prev.faq, { q: trimmedQ, a: trimmedA }],
      }));
      setStatusMessage({ type: 'ok', text: 'Nova pergunta adicionada às Perguntas Frequentes.' });
    },
    [commitData]
  );

  const handleUpdateFaq = useCallback(
    (index: number, field: 'q' | 'a', value: string) => {
      commitData((prev) => {
        const faq = [...prev.faq];
        faq[index] = { ...faq[index], [field]: value };
        return { ...prev, faq };
      });
    },
    [commitData]
  );

  const handleDeleteFaq = useCallback(
    (index: number) => {
      commitData((prev) => ({
        ...prev,
        faq: prev.faq.filter((_, idx) => idx !== index),
      }));
    },
    [commitData]
  );

  // Backup / Export / Reset
  const handleDownloadHtml = useCallback(async () => {
    const ok = await exportStandaloneHtml(data);
    setStatusMessage(
      ok
        ? { type: 'ok', text: 'Arquivo rodaleve-manutencao.html gerado com sucesso.' }
        : { type: 'err', text: 'Não foi possível gerar o HTML atualizado.' }
    );
  }, [data]);

  const handleExportJson = useCallback(() => {
    downloadFile('rodaleve-backup.json', JSON.stringify(data, null, 2), 'application/json');
    setStatusMessage({ type: 'ok', text: 'Backup JSON exportado.' });
  }, [data]);

  const handleImportJson = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as MaintenanceData;
        if (!parsed || !parsed.parts || !parsed.revs) {
          throw new Error('Formato inválido');
        }
        const normalized = normalizeDataModelNames(parsed);
        const res = persistData(normalized);
        setData(res.data);
        setStatusMessage({ type: 'ok', text: 'Backup importado e salvo neste navegador.' });
      } catch {
        setStatusMessage({ type: 'err', text: 'Arquivo de backup inválido.' });
      }
    };
    reader.readAsText(file);
  }, []);

  const handleResetDefault = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore storage error
    }
    setData(getSeedData());
    setStatusMessage({ type: 'ok', text: 'Dados restaurados para a tabela padrão original.' });
  }, []);

  const content = (
    <div id="top" className="min-h-screen flex flex-col bg-[#FAFAFA] dark:bg-[#0C0C0E] text-zinc-900 dark:text-zinc-100">
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      <Header
        isAdmin={isAdmin}
        activeTab={activeTab}
        onNavigateTab={setActiveTab}
        onJumpToLocations={() => {
          document.getElementById('unidades')?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {isAdmin && (
        <AdminToolbar
          isEditing={isEditing}
          onToggleEditing={() => setIsEditing((e) => !e)}
          onDownloadHtml={handleDownloadHtml}
          onExportJson={handleExportJson}
          onImportJson={handleImportJson}
          onResetDefault={handleResetDefault}
          onExitAdmin={handleToggleAdmin}
          statusMessage={statusMessage}
          onClearStatus={() => setStatusMessage(null)}
        />
      )}

      {/* Editorial Title & Section Switcher */}
      <div className="bg-white dark:bg-[#121215] border-b border-zinc-200 dark:border-zinc-800">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-7 sm:py-9 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-zinc-900 dark:text-white [text-wrap:balance]">
              Tabela de Manutenção e Revisões
            </h1>
            <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400">
              Consulte peças genuínas e valores estimados por modelo da 1ª à 7ª revisão programada.
            </p>
          </div>

          {/* Section Switcher (also accessible on mobile) */}
          <div className="flex items-center gap-1.5 p-1 bg-zinc-100 dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 self-start md:self-auto overflow-x-auto max-w-full">
            <button
              type="button"
              onClick={() => {
                if (activeTab === 'faq' || activeTab === 'precos') {
                  setActiveTab(isAdmin ? '1' : firstVisibleRevision);
                }
              }}
              className={`px-3.5 py-2 rounded-md text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab !== 'faq' && activeTab !== 'precos'
                  ? 'bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              Tabela por Modelo
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('faq')}
              className={`px-3.5 py-2 rounded-md text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === 'faq'
                  ? 'bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
              }`}
            >
              Perguntas Frequentes
            </button>
            {isAdmin && (
              <button
                type="button"
                onClick={() => setActiveTab('precos')}
                className={`px-3.5 py-2 rounded-md text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  activeTab === 'precos'
                    ? 'bg-white dark:bg-[#1E1E24] text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
                }`}
              >
                Peças e Preços
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Container */}
      <main id="catalogo" className="flex-1 max-w-[1200px] w-full mx-auto px-4 sm:px-6 py-8 space-y-10">
        {activeTab === 'faq' ? (
          <FaqSection
            faq={data.faq}
            isAdmin={isAdmin}
            isEditing={isEditing}
            onAddFaq={handleAddFaq}
            onUpdateFaq={handleUpdateFaq}
            onDeleteFaq={handleDeleteFaq}
          />
        ) : activeTab === 'precos' && isAdmin ? (
          <PartsManager
            data={data}
            onAddPart={handleAddPart}
            onUpdatePart={handleUpdatePart}
            onDeletePart={handleDeletePart}
          />
        ) : (
          <RevisionCatalog
            data={data}
            activeTab={activeTab}
            isAdmin={isAdmin}
            isEditing={isEditing}
            onSelectTab={setActiveTab}
            onUpdateModelName={handleUpdateModelName}
            onUploadPhoto={handleUploadPhoto}
            onRemovePhoto={handleRemovePhoto}
            onUpdateItemQty={handleUpdateItemQty}
            onUpdatePartPrice={handleUpdatePartPrice}
            onRemoveItem={handleRemoveItem}
            onAddItem={handleAddItem}
            onDeleteModel={handleDeleteModel}
            onToggleHiddenModel={handleToggleHiddenModel}
            onAddModel={handleAddModel}
            onUpdateModelCategory={handleUpdateModelCategory}
            onAddCategory={handleAddCategory}
            onRenameCategory={handleRenameCategory}
            onDeleteCategory={handleDeleteCategory}
            onToggleHiddenCategory={handleToggleHiddenCategory}
            onReorderModels={handleReorderModels}
            onToggleHiddenRevision={handleToggleHiddenRevision}
            onCopyRevisionToOthers={handleCopyRevisionToOthers}
          />
        )}

        <DealershipMapSection hasApiKey={Boolean(MAPS_API_KEY)} />
      </main>

      <FooterSection
        isDark={isDark}
        onToggleTheme={() => setIsDark((d) => !d)}
        isAdmin={isAdmin}
        onToggleAdmin={handleToggleAdmin}
      />

      <WhatsAppFloat />
    </div>
  );

  if (MAPS_API_KEY) {
    return (
      <APIProvider
        apiKey={MAPS_API_KEY}
        language="pt-BR"
        region="BR"
        libraries={['places', 'marker', 'routes']}
      >
        {content}
      </APIProvider>
    );
  }

  return content;
}
