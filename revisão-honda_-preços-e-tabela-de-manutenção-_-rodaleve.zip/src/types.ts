export interface PartItem {
  n: string; // Nome da peça
  c: string; // Código Honda
  p: number; // Preço unitário em R$
}

export interface RevisionPartRef {
  p: string; // ID da peça (ex: "p1")
  q: number; // Quantidade
}

export interface CategoryDef {
  id: string;
  label: string;
}

export interface ModelRevision {
  m: string; // Nome do modelo
  cat?: string; // Categoria opcional (ID de categoria)
  hidden?: boolean; // Se true, oculta o modelo no modo cliente
  i: RevisionPartRef[];
}

export interface FaqItem {
  q: string;
  a: string;
}

export interface MaintenanceData {
  n: number;
  parts: Record<string, PartItem>;
  revs: Record<string, ModelRevision[]>;
  photos: Record<string, string>;
  categories?: CategoryDef[];
  hiddenRevs?: string[];
  hiddenCategories?: string[];
  faq: FaqItem[];
  ts: number;
}

export type ActiveTab = '1' | '2' | '3' | '4' | '5' | '6' | '7' | 'faq' | 'precos';

export type ModelCategory = string;
